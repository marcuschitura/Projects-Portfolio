% N-DOF lumped-parameter LATERAL bridge model with 3 ATMDs and LQR control
% HIGH PRE-STRETCH ASSUMPTION: Springs initially stretched greatly from relaxed length
% This makes lateral stiffness ≈ longitudinal stiffness (linear behavior)
% Adds 3 ATMDs at specified locations with sum-force penalty LQR control

    %% User parameters
    L = 30;            % total length (m)
    N = 13;            % number of lumped masses / DOF

    % Base values (same as longitudinal due to high pre-stretch assumption)
    ms = 294.375;      % mass per lumped DOF (kg)
    ks_internal = 11621.459; % internal stiffness between masses (N/m)
    cs_internal = 1849.612;  % internal damping between masses (Ns/m)

    % High pre-stretch parameters for LATERAL motion
    L0_stretch = 5.0;   % initial stretch length >> natural spring length (m)
    fprintf('=== Lateral BRIDGE MODEL (HIGH PRE-STRETCH) ===\n');
    fprintf('Pre-stretch assumption: L0 = %.1f m >> natural length\n', L0_stretch);
    fprintf('This ensures Lateral frequencies ≈ longitudinal frequencies\n');
    fprintf('Lateral stiffness becomes LINEAR due to geometric effects\n\n');

    % End (abutment) stiffness/damping — slightly lower than internal
    end_scale = 5;   % scale factor for end springs/dampers (choose <1)
    k_end = end_scale * ks_internal;
    c_end = end_scale * cs_internal;

    % Optional: light aerodynamic damping for Lateral motion
    include_aero_damping = false;
    if include_aero_damping
        c_aero_factor = 0.05;  % 5% additional aerodynamic damping
        cs_aero = c_aero_factor * cs_internal;
        cs_internal = cs_internal + cs_aero;
        fprintf('Added aerodynamic damping: %.1f%% of structural damping\n', c_aero_factor*100);
    end

    % Location where external lateral pedestrian/force is applied
    load_index = ceil(N/2);

    %% ATMD parameters - 3 ATMDs with different properties
    % Target natural frequencies for optimal Lateral control
    target_freqs = [0.2527, 0.9731, 1.1884]; % Hz - 3 frequencies covering key modes
    
    % Different masses for each ATMD
    ma_values = [117.75, 117.75*1.2, 117.75*0.9]; % 3 different masses
    
    % Calculate stiffness for each ATMD based on target frequency
    ka_values = zeros(1, 3);
    for i = 1:3
        omega_n = 2 * pi * target_freqs(i); % rad/s
        ka_values(i) = ma_values(i) * omega_n^2; % Stiffness = m * ω²
    end
    
    % Different damping values for each ATMD
    zeta_values = [0.05, 0.04, 0.06];  % 3 different damping ratios
    ca_values = zeros(1, 3);
    for i = 1:3
        omega_n = 2 * pi * target_freqs(i); % rad/s
        ca_values(i) = 2 * zeta_values(i) * ma_values(i) * omega_n; % c = 2ζmω
    end
    
    % ATMD attachment points - optimal locations for Lateral control
    % Placed at anti-nodes of first few Lateral modes
    atmd_locations = [3, 7, 12];  % 3 symmetric locations for good modal coverage
    n_atmd = length(atmd_locations);
    
    fprintf('Adding %d ATMDs for Lateral control at bridge masses: %s\n', ...
            n_atmd, mat2str(atmd_locations));
    fprintf('ATMD parameters:\n');
    for i = 1:n_atmd
        fprintf('  ATMD %d (Mass %d): m=%.2f kg, k=%.2f N/m, c=%.2f Ns/m, fn=%.4f Hz, ζ=%.3f\n', ...
                i, atmd_locations(i), ma_values(i), ka_values(i), ca_values(i), target_freqs(i), zeta_values(i));
    end

    %% ATMD electromagnetic parameters
    % Define electromagnetic parameters for each ATMD
    Bl = [35.5, 31.2, 39.8];     % Force constant for each ATMD (N/A)
    Re = [2.3, 2.5, 2.1];       % Coil resistance for each ATMD (Ohms)
    Le = [0.0025, 0.0028, 0.0022]; % Coil inductance for each ATMD (H)
    
    fprintf('\nATMD electromagnetic parameters:\n');
    for i = 1:n_atmd
        fprintf('  ATMD %d: Bl=%.1f N/A, Re=%.1f Ω, Le=%.3f H\n', ...
                i, Bl(i), Re(i), Le(i));
    end

    %% Build original bridge mass matrix (diagonal) - SAME as longitudinal
    M_bridge = ms * eye(N);

    %% Build stiffness vector - SAME as longitudinal due to pre-stretch
    % High pre-stretch makes Lateral behavior identical to axial
    k = zeros(N+1,1);
    k(1) = k_end;
    k(2:N) = ks_internal;   % SAME stiffness as longitudinal!
    k(N+1) = k_end;

    %% Build damping vector - nearly same as longitudinal
    c = zeros(N+1,1);
    c(1) = c_end;
    c(2:N) = cs_internal;   % includes aerodynamic contribution
    c(N+1) = c_end;

    %% Assemble tridiagonal K and C matrices for bridge - SAME assembly
    K_bridge = zeros(N);
    C_bridge = zeros(N);
    for i = 1:N
        K_bridge(i,i) = k(i) + k(i+1);
        C_bridge(i,i) = c(i) + c(i+1);
        if i < N
            K_bridge(i,i+1) = -k(i+1);
            K_bridge(i+1,i) = -k(i+1);
            C_bridge(i,i+1) = -c(i+1);
            C_bridge(i+1,i) = -c(i+1);
        end
    end

    %% Modal analysis of original bridge (needed for excitation pattern)
    [Phi, Lambda] = eig(K_bridge, M_bridge);
    omega_sq = diag(Lambda);
    omega = sqrt(omega_sq);
    fn = omega / (2*pi);
    [fn_sorted, idx] = sort(fn);
    Phi = Phi(:, idx);

    fprintf('Original Lateral bridge natural frequencies (Hz):\n');
    fprintf('(Should be ≈ longitudinal frequencies due to pre-stretch)\n');
    disp(fn_sorted(1:min(6,N))');

    %% Automated multi-point excitation pattern based on Lateral mode shapes
    mode_to_test = 2;  % Test first Lateral mode
    
    % Lateral mode shape vector
    mode_shape = Phi(:, mode_to_test);
    mode_shape = mode_shape / max(abs(mode_shape));
    
    % Threshold for significant modal participation
    threshold = 1;  % Only excite DOFs with >= 90% of peak amplitude
    excitation_pattern = zeros(N, 1);
    significant_dofs = abs(mode_shape) >= threshold;
    excitation_pattern(significant_dofs) = sign(mode_shape(significant_dofs));

    fprintf('\nLateral Mode %d excitation pattern:\n', mode_to_test);
    fprintf('Exciting bridge masses: ');
    excited_masses = find(excitation_pattern ~= 0);
    fprintf('%s\n', mat2str(excited_masses'));
    fprintf('Modal frequency: %.4f Hz\n', fn_sorted(mode_to_test));
    disp(excitation_pattern');

    %% Augmented system with ATMDs for Lateral control
    % State vector: [x_bridge_Lateral; x_atmd_Lateral; x_bridge_dot; x_atmd_dot]
    % All motions are now in the Lateral direction
    
    total_dof = N + n_atmd;  % Total degrees of freedom
    
    % Augmented mass matrix
    M = zeros(total_dof);
    M(1:N, 1:N) = M_bridge;                    % Bridge masses (Lateral motion)
    for i = 1:n_atmd
        M(N + i, N + i) = ma_values(i);        % ATMD masses (Lateral motion) - individual values
    end
    
    % Augmented stiffness matrix
    K = zeros(total_dof);
    K(1:N, 1:N) = K_bridge;                    % Bridge Lateral stiffness
    
    % Add ATMD stiffness coupling (Lateral direction) - individual values
    for i = 1:n_atmd
        bridge_dof = atmd_locations(i);        % Bridge DOF this ATMD connects to
        atmd_dof = N + i;                      % ATMD DOF index
        
        % ATMD stiffness affects both bridge and ATMD (Lateral coupling)
        K(bridge_dof, bridge_dof) = K(bridge_dof, bridge_dof) + ka_values(i);
        K(bridge_dof, atmd_dof) = -ka_values(i);
        K(atmd_dof, bridge_dof) = -ka_values(i);
        K(atmd_dof, atmd_dof) = ka_values(i);
    end
    
    % Augmented damping matrix
    C = zeros(total_dof);
    C(1:N, 1:N) = C_bridge;                    % Bridge Lateral damping
    
    % Add ATMD damping coupling (Lateral direction) - individual values
    for i = 1:n_atmd
        bridge_dof = atmd_locations(i);        % Bridge DOF this ATMD connects to
        atmd_dof = N + i;                      % ATMD DOF index
        
        % ATMD damping affects both bridge and ATMD (Lateral coupling)
        C(bridge_dof, bridge_dof) = C(bridge_dof, bridge_dof) + ca_values(i);
        C(bridge_dof, atmd_dof) = -ca_values(i);
        C(atmd_dof, bridge_dof) = -ca_values(i);
        C(atmd_dof, atmd_dof) = ca_values(i);
    end

    %% State-space matrices for open-loop system
    Zero = zeros(total_dof);
    I = eye(total_dof);
    A_ol = [Zero, I; -M\K, -M\C];
    
    % External force vector for state-space (Lateral forces)
    B_ext = zeros(2*total_dof, 1);
    B_ext(total_dof + (1:N)) = excitation_pattern / ms;  % Lateral force per unit mass
    
    % ATMD control input matrix (Lateral control forces)
    B_ctrl = zeros(2*total_dof, n_atmd);
    for i = 1:n_atmd
        bridge_dof = atmd_locations(i);
        atmd_dof = N + i;
        
        % Control force affects both bridge mass and ATMD mass (Newton's 3rd law)
        % All forces are in Lateral direction
        B_ctrl(total_dof + bridge_dof, i) = 1/ms;    % Lateral force on bridge mass
        B_ctrl(total_dof + atmd_dof, i) = -1/ma_values(i);  % Reaction force on ATMD (FIXED SIGN)
    end
    
    % Combined input matrix [external_Lateral_force, atmd_Lateral_forces]
    B_combined = [B_ext, B_ctrl];

    % Output matrices for Lateral motion
    nb = N;                % bridge DOFs
    na = n_atmd;           % actuator DOFs
    td = total_dof;        % N + n_atmd

    % Output: Lateral displacements and ATMD displacements
    C_out = [eye(nb), zeros(nb, na), zeros(nb, nb), zeros(nb, na);   % bridge Lateral displacements
             zeros(na, nb), eye(na), zeros(na, nb), zeros(na, na)];  % ATMD Lateral displacements
    
    % Alternative output matrix for all displacements
    C_out1 = zeros(total_dof, 2*total_dof);
    C_out1(1:N, 1:N) = eye(N);  % Bridge Lateral displacements
    
    % Bridge accelerations (Lateral)
    Ea = [eye(N), zeros(N, n_atmd)];  % Select bridge DOFs only
    E_bridge = -Ea * [inv(M)*K, inv(M)*C]; 

    %% Display summary
    fprintf('\nN-DOF Lateral Bridge with ATMDs: N = %d, total length = %.1f m\n', N, L);
    fprintf('Bridge mass per DOF = %.2f kg\n', ms);
    fprintf('Total system DOF = %d (Bridge: %d, ATMDs: %d)\n', total_dof, N, n_atmd);
    fprintf('All motion is in the Lateral direction\n');

    %% LQR Controller Design for Lateral Vibration Control
    
    A_ctrl = A_ol;
    B_ctrl_lqr = B_ctrl;
    
    % LQR weighting matrices optimized for Lateral control
    n_states = size(A_ctrl, 1);
    
    Q = zeros(n_states);
    
    % Heavy penalty on bridge Lateral displacements
    bridge_disp_weight = 1e-4;  % Prioritize Lateral displacement control
    max_acceptable_Lateral_disp = 0.0001;  % 1mm max Lateral displacement (tighter)
    for i = 1:N
        Q(i, i) = bridge_disp_weight / (max_acceptable_Lateral_disp^2);
    end
    
    % Moderate penalty on bridge Lateral velocities
    bridge_vel_weight = 1e4;
    max_acceptable_Lateral_vel = 0.0001;  % 1mm/s max Lateral velocity (tighter)
    for i = 1:N
        Q(total_dof + i, total_dof + i) = bridge_vel_weight / (max_acceptable_Lateral_vel^2);
    end
    
    % Light penalty on ATMD states (Lateral motion)
    atmd_disp_weight = 1e-2;
    atmd_vel_weight = 1e-2;
    for i = 1:n_atmd
        Q(N + i, N + i) = atmd_disp_weight / (0.05^2);  % ATMD Lateral displacement
        Q(total_dof + N + i, total_dof + N + i) = atmd_vel_weight / (0.5^2);  % ATMD Lateral velocity
    end
    
    % R matrix with sum-force penalty for coordinated Lateral control
    R_base = 1e3 * eye(n_atmd);  % Base control effort penalty
    lambda_sum = 1e-4; %Sum-force penalty (promotes coordinated action)
    R = R_base + lambda_sum * (ones(n_atmd, 1) * ones(1, n_atmd));
    
    fprintf('\nDesigning LQR controller for Lateral vibration control...\n');
    fprintf('Sum-force penalty weight: %.1e (encourages coordinated ATMD action)\n', lambda_sum);
    
    % Solve LQR for Lateral control
    [K_lqr, S, E] = lqr(A_ctrl, B_ctrl_lqr, Q, R);
    
    % Closed-loop system
    A_cl = A_ctrl - B_ctrl_lqr * K_lqr;
    B_cl = B_ext;  % External Lateral disturbance input
    
    fprintf('LQR controller designed for Lateral motion. Closed-loop poles (first 10):\n');
    cl_poles = eig(A_cl);
    [~, idx] = sort(abs(real(cl_poles)));
    for i = 1:min(10, length(cl_poles))
        pole = cl_poles(idx(i));
        if abs(imag(pole)) < 1e-10
            fprintf('  %.4f\n', real(pole));
        else
            freq_hz = abs(imag(pole))/(2*pi);
            damping = -real(pole)/abs(pole);
            fprintf('  %.4f ± %.4fj (f=%.3f Hz, ζ=%.3f)\n', real(pole), imag(pole), freq_hz, damping);
        end
    end

    fprintf('\nAugmented system matrices and results saved to workspace.\n');

    G = 35;          % Lateral force component (N)
    f = 0.5016      % Forcing frequency (Hz), ~step frequency
    n = 39;          % Number of pedestrians (assumed)
    S = 18;          % Area occupied by pedestrians (m²) - 0.5 m² per pedestrian
    psi = 0.8;       % Reduction coefficient
    
    %% Calculate equivalent number of pedestrians per m²
    n_prime = (10.8 * sqrt(5*n)) / S;

    %% Simulation parameters
    dt = 0.01;          % Time step (s)
    t_end = 100;         % Simulation duration (s)
    t = 0:dt:t_end;     % Time vector

    %% Lateral pedestrian force function (from your specification)
    lateral_force = @(t) G * cos(2*pi*f*t) * n_prime * psi;

    %% Initialize simulation
    n_states = size(A_ol, 1);
    x_ol = zeros(n_states, length(t));  % Open-loop states
    x_cl = zeros(n_states, length(t));  % Closed-loop states

    % Control forces
    u_ctrl = zeros(n_atmd, length(t));

    %% Simulate open-loop system
    disp('Simulating open-loop system...');
    for i = 2:length(t)
        % State derivative
        xdot_ol = A_ol * x_ol(:, i-1) + B_ext * lateral_force(t(i-1));
        
        % Euler integration
        x_ol(:, i) = x_ol(:, i-1) + xdot_ol * dt;
    end

    %% Simulate closed-loop system
    disp('Simulating closed-loop system...');
    for i = 2:length(t)
        % Calculate control force
        u_ctrl(:, i-1) = -K_lqr * x_cl(:, i-1);
        
        % State derivative
        xdot_cl = A_cl * x_cl(:, i-1) + B_ext * lateral_force(t(i-1));
        
        % Euler integration
        x_cl(:, i) = x_cl(:, i-1) + xdot_cl * dt;
    end

    % Calculate last control force
    u_ctrl(:, end) = -K_lqr * x_cl(:, end);

    %% Extract results
    % Bridge displacements (first N states)
    bridge_disp_ol = x_ol(1:N, :);
    bridge_disp_cl = x_cl(1:N, :);

    % Bridge accelerations (approximate from derivatives)
    bridge_acc_ol = zeros(N, length(t));
    bridge_acc_cl = zeros(N, length(t));
    for i = 2:length(t)-1
        bridge_acc_ol(:, i) = (x_ol(total_dof+1:total_dof+N, i+1) - ...
                              x_ol(total_dof+1:total_dof+N, i-1)) / (2*dt);
        bridge_acc_cl(:, i) = (x_cl(total_dof+1:total_dof+N, i+1) - ...
                              x_cl(total_dof+1:total_dof+N, i-1)) / (2*dt);
    end

    % ATMD displacements and velocities - CORRECTED INDEXING
    atmd_disp = x_cl(N+1:N+n_atmd, :);                    % ATMD positions
    atmd_vel = x_cl(total_dof+N+1:total_dof+N+n_atmd, :); % ATMD velocities

    %% CORRECTED Energy Demand Calculation

    % Extract bridge velocities for ATMD attachment points
    bridge_vel = x_cl(total_dof+1:total_dof+N, :);  % All bridge velocities
    
    % Calculate current for each ATMD: i = F / (Bl)
    i_atmd = zeros(n_atmd, length(t));
    for i = 1:n_atmd
        i_atmd(i, :) = u_ctrl(i, :) / Bl(i);  % Current for each ATMD
    end

    % Calculate current derivative using central difference
    di_dt = zeros(size(i_atmd));
    for i = 1:n_atmd
        for k = 2:length(t)-1
            di_dt(i, k) = (i_atmd(i, k+1) - i_atmd(i, k-1)) / (2*dt);
        end
        % Fix boundaries
        di_dt(i, 1) = (i_atmd(i, 2) - i_atmd(i, 1)) / dt;
        di_dt(i, end) = (i_atmd(i, end) - i_atmd(i, end-1)) / dt;
    end

    % Calculate relative velocity: ATMD vs attached bridge node
    relative_vel = zeros(n_atmd, length(t));
    for i = 1:n_atmd
        node_idx = atmd_locations(i);  % Bridge node this ATMD is attached to
        relative_vel(i, :) = atmd_vel(i, :) - bridge_vel(node_idx, :);
    end

    % Calculate voltage for each ATMD: V = L*di/dt + R*i + Bl*v_rel
    u_voltage = zeros(n_atmd, length(t));
    for i = 1:n_atmd
        u_voltage(i, :) = Le(i) * di_dt(i, :) + Re(i) * i_atmd(i, :) + Bl(i) * relative_vel(i, :);
    end

    % Calculate instantaneous electrical power: P = V * I
    power_elec = u_voltage .* i_atmd;

    % Calculate energy demands
    E_net = zeros(n_atmd, 1);  % Net energy (can be negative due to regeneration)
    E_abs = zeros(n_atmd, 1);  % Absolute energy consumption
    
    for i = 1:n_atmd
        E_net(i) = trapz(t, power_elec(i, :));        % Net energy
        E_abs(i) = trapz(t, abs(power_elec(i, :)));   % Absolute energy
    end

   
%% RESULTS PLOTTING - Lateral BRIDGE WITH ATMD CONTROL

%% 1. Bridge Displacement Comparison (Controlled vs Uncontrolled)
figure('Position', [100 100 1200 800]);

% Maximum displacement envelope
subplot(2,2,1);
max_disp_ol = max(abs(bridge_disp_ol), [], 2);
max_disp_cl = max(abs(bridge_disp_cl), [], 2);
bridge_positions = linspace(0, L, N);
plot(bridge_positions, max_disp_ol*1000, 'r-', 'LineWidth', 2, 'DisplayName', 'Uncontrolled');
hold on;
plot(bridge_positions, max_disp_cl*1000, 'b-', 'LineWidth', 2, 'DisplayName', 'Controlled');
xlabel('Bridge Position (m)');
ylabel('Max Displacement (mm)');
title('Maximum Lateral Displacement Envelope');
legend('show');
grid on;

% Mark ATMD locations
for i = 1:n_atmd
    pos_idx = atmd_locations(i);
    x_pos = bridge_positions(pos_idx);
    plot(x_pos, max_disp_cl(pos_idx)*1000, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'red');
    text(x_pos, max_disp_cl(pos_idx)*1000*1.1, sprintf('ATMD%d', i), ...
         'HorizontalAlignment', 'center');
end

% Displacement time history at mid-span
subplot(2,2,2);
mid_span = ceil(N/2);
plot(t, bridge_disp_ol(mid_span,:)*1000, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Uncontrolled');
hold on;
plot(t, bridge_disp_cl(mid_span,:)*1000, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Controlled');
xlabel('Time (s)');
ylabel('Displacement (mm)');
title(sprintf('Mid-Span (Mass %d) Lateral Displacement', mid_span));
legend('show');
grid on;

% Displacement reduction percentage
reduction = (max_disp_ol - max_disp_cl) ./ max_disp_ol * 100;
subplot(2,2,3);
bar(bridge_positions, reduction);
xlabel('Bridge Position (m)');
ylabel('Displacement Reduction (%)');
title('Control Effectiveness - Displacement Reduction');
grid on;

% RMS displacement comparison
subplot(2,2,4);
rms_disp_ol = rms(bridge_disp_ol, 2);
rms_disp_cl = rms(bridge_disp_cl, 2);
bar([rms_disp_ol(mid_span), rms_disp_cl(mid_span)]*1000);
set(gca, 'XTickLabel', {'Uncontrolled', 'Controlled'});
ylabel('RMS Displacement (mm)');
title('Mid-Span RMS Displacement Comparison');
grid on;

fprintf('\n=== DISPLACEMENT RESULTS ===\n');
fprintf('Maximum uncontrolled displacement: %.3f mm\n', max(max_disp_ol)*1000);
fprintf('Maximum controlled displacement: %.3f mm\n', max(max_disp_cl)*1000);
fprintf('Overall displacement reduction: %.1f%%\n', mean(reduction));

%% 2. Bridge Acceleration Comparison
figure('Position', [100 100 1200 600]);

% Maximum acceleration envelope
subplot(1,2,1);
max_acc_ol = max(abs(bridge_acc_ol), [], 2);
max_acc_cl = max(abs(bridge_acc_cl), [], 2);
plot(bridge_positions, max_acc_ol, 'r-', 'LineWidth', 2, 'DisplayName', 'Uncontrolled');
hold on;
plot(bridge_positions, max_acc_cl, 'b-', 'LineWidth', 2, 'DisplayName', 'Controlled');
xlabel('Bridge Position (m)');
ylabel('Max Acceleration (m/s²)');
title('Maximum Lateral Acceleration Envelope');
legend('show');
grid on;

% Mark ATMD locations
for i = 1:n_atmd
    pos_idx = atmd_locations(i);
    x_pos = bridge_positions(pos_idx);
    plot(x_pos, max_acc_cl(pos_idx), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'red');
end

% Acceleration time history at mid-span
subplot(1,2,2);
plot(t, bridge_acc_ol(mid_span,:), 'r-', 'LineWidth', 1.5, 'DisplayName', 'Uncontrolled');
hold on;
plot(t, bridge_acc_cl(mid_span,:), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Controlled');
xlabel('Time (s)');
ylabel('Acceleration (m/s²)');
title(sprintf('Mid-Span (Mass %d) Lateral Acceleration', mid_span));
legend('show');
grid on;

% Acceleration reduction
acc_reduction = (max_acc_ol - max_acc_cl) ./ max_acc_ol * 100;
fprintf('\n=== ACCELERATION RESULTS ===\n');
fprintf('Maximum uncontrolled acceleration: %.3f m/s²\n', max(max_acc_ol));
fprintf('Maximum controlled acceleration: %.3f m/s²\n', max(max_acc_cl));
fprintf('Overall acceleration reduction: %.1f%%\n', mean(acc_reduction));

%% 3. ATMD Performance Analysis
figure('Position', [100 100 1400 900]);

% ATMD displacements
subplot(2,3,1);
for i = 1:n_atmd
    plot(t, atmd_disp(i,:)*1000, 'LineWidth', 1.5, 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('Time (s)');
ylabel('Displacement (mm)');
title('ATMD Lateral Displacements');
legend('show');
grid on;

% ATMD control forces
subplot(2,3,2);
for i = 1:n_atmd
    plot(t, u_ctrl(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('Time (s)');
ylabel('Control Force (N)');
title('ATMD Control Forces');
legend('show');
grid on;

% ATMD stroke vs force
subplot(2,3,3);
for i = 1:n_atmd
    scatter(atmd_disp(i,:)*1000, u_ctrl(i,:), 20, 'filled', 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('ATMD Stroke (mm)');
ylabel('Control Force (N)');
title('ATMD Force vs Stroke');
legend('show');
grid on;

% ATMD stroke histogram
subplot(2,3,4);
stroke_rms = rms(atmd_disp, 2)*1000;
stroke_max = max(abs(atmd_disp), [], 2)*1000;
bar_matrix = [stroke_rms, stroke_max];
bar(bar_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Stroke (mm)');
title('ATMD Stroke Statistics');
legend('RMS', 'Max', 'Location', 'northwest');
grid on;

% Control force statistics
subplot(2,3,5);
force_rms = rms(u_ctrl, 2);
force_max = max(abs(u_ctrl), [], 2);
bar_matrix = [force_rms, force_max];
bar(bar_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Control Force (N)');
title('Control Force Statistics');
legend('RMS', 'Max', 'Location', 'northwest');
grid on;

% ATMD stroke utilization
subplot(2,3,6);
design_stroke = 0.1 * 1000; % 10cm design stroke in mm
stroke_utilization = (stroke_max / design_stroke) * 100;
bar(stroke_utilization);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Stroke Utilization (%)');
title('ATMD Stroke Utilization (10cm design)');
ylim([0 100]);
grid on;

fprintf('\n=== ATMD PERFORMANCE ===\n');
for i = 1:n_atmd
    fprintf('ATMD %d: Max stroke = %.1f mm, Max force = %.1f N, RMS force = %.1f N\n', ...
            i, stroke_max(i), force_max(i), force_rms(i));
end

%% 4. Power Feasibility Analysis - Current, Voltage, Power
figure('Position', [100 100 1400 1000]);

% Current time history
subplot(3,3,1);
for i = 1:n_atmd
    plot(t, i_atmd(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('Time (s)');
ylabel('Current (A)');
title('ATMD Coil Current');
legend('show');
grid on;

% Current statistics
subplot(3,3,2);
current_rms = rms(i_atmd, 2);
current_max = max(abs(i_atmd), [], 2);
bar_matrix = [current_rms, current_max];
bar(bar_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Current (A)');
title('Current Statistics');
legend('RMS', 'Peak', 'Location', 'northwest');
grid on;

% Voltage time history
subplot(3,3,4);
for i = 1:n_atmd
    plot(t, u_voltage(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('Time (s)');
ylabel('Voltage (V)');
title('ATMD Terminal Voltage');
legend('show');
grid on;

% Voltage statistics
subplot(3,3,5);
voltage_rms = rms(u_voltage, 2);
voltage_max = max(abs(u_voltage), [], 2);
bar_matrix = [voltage_rms, voltage_max];
bar(bar_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Voltage (V)');
title('Voltage Statistics');
legend('RMS', 'Peak', 'Location', 'northwest');
grid on;

% Instantaneous power
subplot(3,3,7);
for i = 1:n_atmd
    plot(t, power_elec(i,:), 'LineWidth', 1.5, 'DisplayName', sprintf('ATMD %d', i));
    hold on;
end
xlabel('Time (s)');
ylabel('Power (W)');
title('Instantaneous Electrical Power');
legend('show');
grid on;

% Power statistics
subplot(3,3,8);
power_rms = rms(power_elec, 2);
power_max = max(abs(power_elec), [], 2);
bar_matrix = [power_rms, power_max];
bar(bar_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Power (W)');
title('Power Statistics');
legend('RMS', 'Peak', 'Location', 'northwest');
grid on;

% Energy analysis
subplot(3,3,3);
bar([E_net, E_abs]);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Energy (J)');
title('Energy Consumption');
legend('Net Energy', 'Absolute Energy', 'Location', 'northwest');
grid on;

% Regeneration efficiency
subplot(3,3,6);
regeneration_efficiency = (E_abs - E_net) ./ E_abs * 100;
bar(regeneration_efficiency);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Regeneration Efficiency (%)');
title('Energy Regeneration Efficiency');
grid on;

% Power feasibility check
subplot(3,3,9);
% Typical amplifier limits
typical_current_limit = 10; % A
typical_voltage_limit = 240; % V
typical_power_limit = 2000; % W

feasibility_current = (current_max <= typical_current_limit) * 100;
feasibility_voltage = (voltage_max <= typical_voltage_limit) * 100;
feasibility_power = (power_max <= typical_power_limit) * 100;

feasibility_matrix = [feasibility_current, feasibility_voltage, feasibility_power];
bar(feasibility_matrix);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('ATMD%d', x), 1:n_atmd, 'UniformOutput', false));
ylabel('Feasibility (%)');
title('Power Amplifier Feasibility (Green = Within Limits)');
legend('Current (10A)', 'Voltage (240V)', 'Power (2kW)', 'Location', 'southwest');
ylim([0 100]);
grid on;

fprintf('\n=== POWER FEASIBILITY ANALYSIS ===\n');
fprintf('Typical amplifier limits: 10A current, 240V voltage, 2kW power\n\n');
for i = 1:n_atmd
    fprintf('ATMD %d:\n', i);
    fprintf('  Current: %.1f A RMS, %.1f A peak %s\n', ...
            current_rms(i), current_max(i), ...
            ternary(current_max(i) <= typical_current_limit, '(OK)', '(EXCEEDS)'));
    fprintf('  Voltage: %.1f V RMS, %.1f V peak %s\n', ...
            voltage_rms(i), voltage_max(i), ...
            ternary(voltage_max(i) <= typical_voltage_limit, '(OK)', '(EXCEEDS)'));
    fprintf('  Power: %.1f W RMS, %.1f W peak %s\n', ...
            power_rms(i), power_max(i), ...
            ternary(power_max(i) <= typical_power_limit, '(OK)', '(EXCEEDS)'));
    fprintf('  Energy: Net = %.1f J, Abs = %.1f J, Regeneration = %.1f%%\n', ...
            E_net(i), E_abs(i), regeneration_efficiency(i));
end

%% 5. Summary Performance Metrics
figure('Position', [100 100 1000 600]);

% Overall performance comparison
performance_metrics = [
    max(max_disp_ol)*1000, max(max_disp_cl)*1000;
    max(max_acc_ol), max(max_acc_cl);
    max(stroke_max), nan;
    max(force_max), nan;
    max(current_max), typical_current_limit;
    max(voltage_max), typical_voltage_limit;
    max(power_max), typical_power_limit;
];

metric_names = {
    'Max Displacement (mm)'
    'Max Acceleration (m/s²)'
    'Max ATMD Stroke (mm)'
    'Max Control Force (N)'
    'Max Current (A)'
    'Max Voltage (V)'
    'Max Power (W)'
};

subplot(1,2,1);
bar(performance_metrics(1:4,:));
set(gca, 'XTickLabel', metric_names(1:4));
ylabel('Value');
title('Structural Performance Metrics');
legend('Actual', 'Target', 'Location', 'northwest');
grid on;

subplot(1,2,2);
bar(performance_metrics(5:7,:));
set(gca, 'XTickLabel', metric_names(5:7));
ylabel('Value');
title('Electrical System Requirements');
legend('Actual', 'Amplifier Limit', 'Location', 'northwest');
grid on;

%% 6. Control Effort vs Performance Trade-off
figure('Position', [100 100 1200 400]);

% Control effort metrics
control_metrics = [
    mean(force_rms), mean(current_rms), mean(voltage_rms), mean(power_rms);
    mean(reduction), mean(acc_reduction), mean(regeneration_efficiency), 100;
];

subplot(1,2,1);
bar(control_metrics(1,:));
set(gca, 'XTickLabel', {'Force (N)', 'Current (A)', 'Voltage (V)', 'Power (W)'});
ylabel('RMS Value');
title('Average Control Effort per ATMD');
grid on;

subplot(1,2,2);
bar(control_metrics(2,1:3));
set(gca, 'XTickLabel', {'Disp Reduction (%)', 'Accel Reduction (%)', 'Regen Efficiency (%)'});
ylabel('Percentage');
title('Control Performance Metrics');
grid on;

fprintf('\n=== SUMMARY ===\n');
fprintf('Average displacement reduction: %.1f%%\n', mean(reduction));
fprintf('Average acceleration reduction: %.1f%%\n', mean(acc_reduction));
fprintf('Average regeneration efficiency: %.1f%%\n', mean(regeneration_efficiency));
fprintf('Average control force: %.1f N RMS\n', mean(force_rms));
fprintf('Average electrical power: %.1f W RMS\n', mean(power_rms));

%% Helper function for ternary operator
function result = ternary(condition, true_val, false_val)
    if condition
        result = true_val;
    else
        result = false_val;
    end
end
  

 