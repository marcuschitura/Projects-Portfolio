
% Parameters
mb = 588.75;       % Bridge mass 
ms = 294.375;   % Modal mass (kg)
ks = 11621.459; % Modal stiffness (N/m), gives 1 Hz natural frequency
cs = 1849.612;  % Modal damping (Ns/m) for 0.02% damping ratio
ma = 11.775;    % Mass of the actuator (kg)
ca = 16.4182;   % Damping coefficient of the actuator (N/(m/s))
ka = 429.753;   % Stiffness of the actuator (N/m)

Bl = 3.4;
Re = 7.5;
Le = 0.002;

C1 = ca/ms;
C2 = -ca/ms;
C3 = ka/ms;
C4 = -ka/ms;
C5 = -ks/ms;
C6 = -cs/ms;
C7 = -ca/ma;
C8 = ca/ma;
C9 = -ka/ma;
C10 = ka/ma;