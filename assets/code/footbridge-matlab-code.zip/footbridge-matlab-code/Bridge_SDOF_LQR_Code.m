% TMD-Structure State Space Conversion
% Based on equations (7)-(14) from the paper

% Given system parameters
ms = 294.375;   % Modal mass (kg)
ks = 11621.459; % Modal stiffness (N/m), gives 1 Hz natural frequency
cs = 1849.612;  % Modal damping (Ns/m) for 0.02% damping ratio
ma = 11.775;    % Mass of the actuator (kg)
ca = 16.4182;   % Damping coefficient of the actuator (N/(m/s))
ka = 429.753;   % Stiffness of the actuator (N/m)

% Step 1: Form the system matrices M, C, K (Equation 7)
M = [ms,  0;
     0,   ma];

C = [cs + ca, -ca;
     -ca,     ca];

K = [ks + ka, -ka;
     -ka,     ka];

% Input vectors for pedestrian load and control force
B0 = [1; 0];  % Input vector for pedestrian load p*(t)
Bc = [-1; 1]; % Input vector for control force fa(t)

% Step 2: Convert to state-space form (Equations 11-14)
% State vector: z(t) = [xs(t); xa(t); xs_dot(t); xa_dot(t)]

% Identity matrix for state-space conversion
I = eye(2);
Zero = zeros(2);

% State matrix A (Equation 11)
A = [Zero,        I;
     -inv(M)*K,  -inv(M)*C];

% Input matrix B (Equation 12) - for pedestrian load only
B_pedestrian = [zeros(2,1);
                -inv(M)*B0];

% For control input, we need a separate input matrix
B_control = [zeros(2,1);
             -inv(M)*Bc];

% Combined input matrix for both pedestrian load and control force
B_combined = [B_pedestrian, B_control];

% Output matrix E (Equation 13) - for acceleration output
% Ea selects which accelerations we want to output
% For structure acceleration only: Ea = [1, 0]
% For both structure and TMD accelerations: Ea = [1, 0; 0, 1]
Ea = [1, 0];  % Structure acceleration only

E = -Ea * [inv(M)*K, inv(M)*C];

% Feedthrough matrix D (Equation 14)
D_pedestrian = Ea * inv(M) * B0;  % For pedestrian load
D_control = Ea * inv(M) * Bc;     % For control force
D = [D_pedestrian, D_control];    % Combined feedthrough matrix

Q1 = diag([10000, 0.01, 1000, 0.1]);
R1 = 1e-6; % Much smaller R (was 0.0001)
K1 = lqr(A, B_pedestrian, Q1, R1);

% Display results
fprintf('System Matrices:\n');
fprintf('================\n\n');

fprintf('Mass Matrix M:\n');
disp(M);

fprintf('Damping Matrix C:\n');
disp(C);

fprintf('Stiffness Matrix K:\n');
disp(K);

fprintf('\nState-Space Matrices:\n');
fprintf('=====================\n\n');

fprintf('State Matrix A (4x4):\n');
disp(A);

fprintf('Input Matrix B_pedestrian for pedestrian load (4x1):\n');
disp(B_pedestrian);

fprintf('Input Matrix B_control for control force (4x1):\n');
disp(B_control);  %

fprintf('Combined Input Matrix B_combined (4x2):\n');
disp(B_combined);

fprintf('Output Matrix E (1x4) - for structure acceleration:\n');
disp(E);

fprintf('Feedthrough Matrix D (1x2):\n');
disp(D);

% Verify natural frequency
[V, lambda] = eig(K, M);
natural_freq = sqrt(diag(lambda))/(2*pi);
fprintf('\nVerification:\n');
fprintf('=============\n');
fprintf('Natural frequencies: %.3f Hz, %.3f Hz\n', natural_freq(1), natural_freq(2));

% Calculate damping ratios
for i = 1:2
    phi = V(:,i);
    modal_mass = phi' * M * phi;
    modal_damping = phi' * C * phi;
    modal_stiffness = phi' * K * phi;
    damping_ratio = modal_damping / (2 * sqrt(modal_mass * modal_stiffness));
    fprintf('Damping ratio mode %d: %.4f (%.2f%%)\n', i, damping_ratio, damping_ratio*100);
end