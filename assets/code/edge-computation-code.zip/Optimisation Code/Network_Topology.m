function visualize_network_topology()
    % Network Topology Visualization
    % Based on the DAG structure: 1 gNB + 8 IAB nodes
    
    close all;
    
    % Node positions [x, y, z] - updated with IAB-8
    nodes = {
        'gNB ',   [0.0, 0.0, 30.0];
        'IAB-1',     [-100.0, 50.0, 25.0];
        'IAB-2',     [-50.0, 0.0, 25.0];
        'IAB-3',     [50.0, 0.0, 25.0];
        'IAB-4',     [-150.0, 0.0, 20.0];
        'IAB-5',     [0.0, 80.0, 20.0];
        'IAB-6',     [100.0, 50.0, 20.0];
        'IAB-7',     [-200.0, -50.0, 15.0];
        'IAB-8',     [-50.0, -50.0, 25.0];  % NEW NODE
    };
    
    % Connections (from -> to) - updated with new connections
    connections = [
        0, 1;  % gNB -> IAB-1
        0, 2;  % gNB -> IAB-2
        0, 3;  % gNB -> IAB-3
        1, 2;  % IAB-1 -> IAB-2
        1, 3;  % IAB-1 -> IAB-3
        2, 4;  % IAB-2 -> IAB-4
        2, 5;  % IAB-2 -> IAB-5
        3, 6;  % IAB-3 -> IAB-6
        4, 7;  % IAB-4 -> IAB-7
        6, 5;  % IAB-6 -> IAB-5
        6, 7;  % IAB-6 -> IAB-7
        7, 8;  % IAB-7 -> IAB-8  (NEW)
        3, 8;  % IAB-3 -> IAB-8  (NEW)
    ];
    
    % Create figure
    figure('Position', [100, 100, 1200, 800]);
    
    % Plot connections first
    hold on;
    
    % Calculate and display distances for each connection
    distances = [];
    
    for i = 1:size(connections, 1)
        from_node = connections(i, 1) + 1; % MATLAB indexing
        to_node = connections(i, 2) + 1;
        
        from_pos = nodes{from_node, 2};
        to_pos = nodes{to_node, 2};
        
        % Calculate distance
        dist = norm(from_pos - to_pos);
        distances = [distances; dist];
        
        % Plot connection line
        plot3([from_pos(1), to_pos(1)], ...
              [from_pos(2), to_pos(2)], ...
              [from_pos(3), to_pos(3)], ...
              'b-', 'LineWidth', 1.5);
        
        % Calculate midpoint for distance label
        mid_x = (from_pos(1) + to_pos(1)) / 2;
        mid_y = (from_pos(2) + to_pos(2)) / 2;
        mid_z = (from_pos(3) + to_pos(3)) / 2;
        
        % Display distance near the midpoint
        text(mid_x, mid_y, mid_z + 5, ...
             sprintf('%.1fm', dist), ...
             'HorizontalAlignment', 'center', ...
             'BackgroundColor', 'white', ...
             'EdgeColor', 'black', ...
             'FontSize', 8);
    end
    
    % Plot nodes with different colors based on type and layer
    colors = [
        1 0 0;      % gNB - Red
        0 0 1;      % IAB-1 - Blue (Layer 1)
        0 0 1;      % IAB-2 - Blue (Layer 1)
        0 0 1;      % IAB-3 - Blue (Layer 1)
        0 0.5 0;    % IAB-4 - Green (Layer 2)
        0 0.5 0;    % IAB-5 - Green (Layer 2)
        0 0.5 0;    % IAB-6 - Green (Layer 2)
        0.5 0 0.5;  % IAB-7 - Purple (Layer 3)
        1 0.5 0;    % IAB-8 - Orange (Layer 3) - NEW
    ];
    
    sizes = [200, 100, 100, 100, 80, 80, 80, 80, 80]; % Updated sizes
    
    for i = 1:size(nodes, 1)
        pos = nodes{i, 2};
        
        % Plot node
        scatter3(pos(1), pos(2), pos(3), sizes(i), colors(i, :), 'filled');
        
        % Add node label
        text(pos(1), pos(2), pos(3) + 10, nodes{i, 1}, ...
             'HorizontalAlignment', 'center', ...
             'FontWeight', 'bold', ...
             'FontSize', 10);
        
        % Add coordinates
        text(pos(1), pos(2), pos(3) - 8, ...
             sprintf('(%.0f,%.0f,%.0f)', pos(1), pos(2), pos(3)), ...
             'HorizontalAlignment', 'center', ...
             'FontSize', 8, ...
             'Color', [0.3 0.3 0.3]);
    end
    
    % Configure plot
    grid on;
    xlabel('X Position (m)');
    ylabel('Y Position (m)');
    zlabel('Height (m)');
    title('5G IAB Network Topology ', 'FontSize', 14);
    
    % Set equal aspect ratio and adjust view
    axis equal;
    
    % Add legend
    legend_items = {
        'Connections', 'gNB', 'Layer 1 IAB', 'Layer 2 IAB', 'Layer 3 IAB'
    };
    legend(legend_items, 'Location', 'northeastoutside');
    
    % Set nice viewing angle to better see IAB-8
    view(45, 30);
    
    % Adjust axis limits to include IAB-8
    xlim([-220, 120]);
    ylim([-60, 90]);
    zlim([10, 35]);
    
   
    % Display summary in command window
    fprintf('\n=== UPDATED NETWORK TOPOLOGY SUMMARY ===\n');
    fprintf('Total nodes: %d (1 gNB + 8 IAB)\n', size(nodes, 1));
    fprintf('Total connections: %d\n', size(connections, 1));
    fprintf('Distance range: %.1f - %.1f meters\n', min(distances), max(distances));
    fprintf('Average connection distance: %.1f meters\n', mean(distances));
    fprintf('\nNew IAB-8 Details:\n');
    fprintf('  Position: (-50, -50, 25)\n');
    fprintf('  Connections: IAB-7→IAB-8 (%.1f m), IAB-3→IAB-8 (%.1f m)\n', ...
            distances(end-1), distances(end));
    
    fprintf('\nConnection Details:\n');
    for i = 1:size(connections, 1)
        from_node = connections(i, 1);
        to_node = connections(i, 2);
        fprintf('  %s → %s: %.1f m\n', ...
                nodes{from_node + 1, 1}, ...
                nodes{to_node + 1, 1}, ...
                distances(i));
    end
    
    fprintf('\nNode Positions:\n');
    for i = 1:size(nodes, 1)
        pos = nodes{i, 2};
        fprintf('  %s: (%.1f, %.1f, %.1f)\n', nodes{i, 1}, pos(1), pos(2), pos(3));
    end
    
    % Highlight new connections
    fprintf('\n=== NEW CONNECTIONS ADDED ===\n');
    fprintf('1. IAB-7 → IAB-8: %.1f meters\n', distances(end-1));
    fprintf('2. IAB-3 → IAB-8: %.1f meters\n', distances(end));
end

% Run the visualization
visualize_network_topology();