/*
 * mmWave IAB + MEC Hybrid Simulation with DAG Topology
 * MULTIHOP VERSION: Directed Acyclic Graph topology with path finding
 * OPTIMIZED VERSION: 30 UEs, MEC Capacity 20, Queue Size 10
 * ENHANCED: Realistic NLOS/LOS conditions for urban mmWave
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/mmwave-helper.h"
#include "ns3/mmwave-point-to-point-epc-helper.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include <queue>
#include <map>
#include <random>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <set>
#include <cmath>

using namespace ns3;
using namespace mmwave;

NS_LOG_COMPONENT_DEFINE("MmWaveIabMecDAG");

// Forward declarations
struct ComputationTask;

// DAG Node Structure
struct DAGNode {
    uint32_t nodeId;
    Vector position;
    uint32_t depth; // Distance from donor (0 = donor, 1 = first hop, etc.)
    std::vector<uint32_t> parents; // Upstream nodes
    std::vector<uint32_t> children; // Downstream nodes
    uint32_t maxConnections;
    uint32_t currentConnections;
    
    DAGNode(uint32_t id = 0, Vector pos = Vector(0,0,0), uint32_t d = 0) 
        : nodeId(id), position(pos), depth(d), maxConnections(4), currentConnections(0) {}
};

// Link State Manager for NLOS/LOS modeling
class LinkStateManager : public Object {
public:
    enum LinkState { LOS, NLOS, BLOCKED };
    
    struct LinkInfo {
        LinkState state;
        Time lastUpdate;
        Time stateDuration;
        double sinr;
    };
    
    static TypeId GetTypeId() {
        static TypeId tid = TypeId("LinkStateManager")
            .SetParent<Object>()
            .AddConstructor<LinkStateManager>();
        return tid;
    }
    
    LinkStateManager() {
        // Initialize random generator
        m_generator.seed(time(0));
    }
    
    // LOS probability model (3GPP TR 38.901 UMi Street Canyon)
    double CalculateLOSProbability(double distance) {
        if (distance <= 18.0) return 1.0;
        return 18.0 / distance + exp(-distance / 36.0) * (1.0 - 18.0 / distance);
    }
    
    LinkState GetLinkState(uint32_t from, uint32_t to, double distance) {
        auto key = std::make_pair(std::min(from, to), std::max(from, to));
        
        // Update state if never set or if state duration expired
        if (m_linkStates.find(key) == m_linkStates.end() || 
            Simulator::Now() - m_linkStates[key].lastUpdate > m_linkStates[key].stateDuration) {
            
            UpdateLinkState(from, to, distance, key);
        }
        
        return m_linkStates[key].state;
    }
    
    double GetAdditionalLoss(LinkState state) {
        switch (state) {
            case LOS: return 0.0;
            case NLOS: return 20.0; // Additional 20dB for NLOS
            case BLOCKED: return 50.0; // Very high loss for blocked links
            default: return 0.0;
        }
    }
    
    void PrintLinkStates() {
        NS_LOG_INFO("=== LINK STATES ===");
        for (const auto& pair : m_linkStates) {
            std::string stateStr;
            switch (pair.second.state) {
                case LOS: stateStr = "LOS"; break;
                case NLOS: stateStr = "NLOS"; break;
                case BLOCKED: stateStr = "BLOCKED"; break;
            }
            NS_LOG_INFO("Link " << pair.first.first << "->" << pair.first.second 
                       << ": " << stateStr << " (for " << pair.second.stateDuration.GetMilliSeconds() << "ms)");
        }
    }
    
private:
    void UpdateLinkState(uint32_t from, uint32_t to, double distance, std::pair<uint32_t, uint32_t> key) {
        // Calculate LOS probability
        double losProb = CalculateLOSProbability(distance);
        
        // Random decision based on probability
        std::uniform_real_distribution<> probDist(0.0, 1.0);
        double randomValue = probDist(m_generator);
        
        LinkState newState;
        Time stateDuration;
        
        if (randomValue <= losProb) {
            // LOS link
            newState = LOS;
            // LOS links tend to be stable
            std::uniform_real_distribution<> durationDist(500, 2000); // 0.5-2 seconds
            stateDuration = MilliSeconds(durationDist(m_generator));
        } else {
            // Check for temporary blockage vs persistent NLOS
            std::uniform_real_distribution<> blockageDist(0.0, 1.0);
            if (blockageDist(m_generator) < 0.1) { // 10% chance of temporary blockage
                newState = BLOCKED;
                // Blockages are short-lived
                std::uniform_real_distribution<> blockDurationDist(50, 300); // 50-300ms
                stateDuration = MilliSeconds(blockDurationDist(m_generator));
            } else {
                newState = NLOS;
                // NLOS conditions can persist
                std::uniform_real_distribution<> nlosDurationDist(200, 1000); // 0.2-1 second
                stateDuration = MilliSeconds(nlosDurationDist(m_generator));
            }
        }
        
        m_linkStates[key].state = newState;
        m_linkStates[key].lastUpdate = Simulator::Now();
        m_linkStates[key].stateDuration = stateDuration;
        
        NS_LOG_DEBUG("Link " << from << "->" << to << " updated to " 
                    << (newState == LOS ? "LOS" : (newState == NLOS ? "NLOS" : "BLOCKED"))
                    << " for " << stateDuration.GetMilliSeconds() << "ms");
    }
    
    std::map<std::pair<uint32_t, uint32_t>, LinkInfo> m_linkStates;
    std::mt19937 m_generator;
};

// DAG Topology Manager
class DAGTopology : public Object {
public:
    static TypeId GetTypeId() {
        static TypeId tid = TypeId("DAGTopology")
            .SetParent<Object>()
            .AddConstructor<DAGTopology>();
        return tid;
    }
    
    DAGTopology() {}
    
    void InitializeTopology() {
        // Clear existing topology
        m_nodes.clear();
        m_adjacencyList.clear();
    
        // Create DAG topology - UPDATED with IAB-8
        // Layer 0: gNB (Root) - Node 0
        AddNode(0, Vector(0.0, 0.0, 30.0), 0);
    
        // Layer 1: First hop nodes (1, 2, 3)
        AddNode(1, Vector(-100.0, 50.0, 25.0), 1);
        AddNode(2, Vector(-50.0, 0.0, 25.0), 1);
        AddNode(3, Vector(50.0, 0.0, 25.0), 1);
    
        // Layer 2: Second hop nodes (4, 5, 6)
        AddNode(4, Vector(-150.0, 0.0, 20.0), 2);
        AddNode(5, Vector(0.0, 80.0, 20.0), 2);
        AddNode(6, Vector(100.0, 50.0, 20.0), 2);
    
        // Layer 3: Third hop nodes (7, 8)
        AddNode(7, Vector(-200.0, -50.0, 15.0), 3);
        AddNode(8, Vector(-50.0, -50.0, 25.0), 3);  // NEW IAB-8 node
    
        // Create edges - PROPER DAG STRUCTURE
        // gNB (0) connections
        AddEdge(0, 1); // gNB -> 1
        AddEdge(0, 2); // gNB -> 2  
        AddEdge(0, 3); // gNB -> 3
    
        // Layer 1-2 connections
        AddEdge(1, 2); // 1 -> 2
        AddEdge(1, 3); // 1 -> 3
        AddEdge(2, 4); // 2 -> 4
        AddEdge(2, 5); // 2 -> 5
        AddEdge(3, 6); // 3 -> 6
    
        // Layer 2-3 connections
        AddEdge(4, 7); // 4 -> 7
        AddEdge(6, 5); // 6 -> 5
        AddEdge(6, 7); // 6 -> 7
    
        // NEW connections for IAB-8
        AddEdge(7, 8); // 7 -> 8
        AddEdge(3, 8); // 3 -> 8
    
        NS_LOG_INFO("=== UPDATED DAG TOPOLOGY INITIALIZED ===");
        NS_LOG_INFO("Nodes: 9 (1 gNB + 8 IAB)");
        NS_LOG_INFO("Edges: 12 connections");
        NS_LOG_INFO("Max depth: 3 hops");
        PrintTopology();
    }
    
    void AddNode(uint32_t nodeId, Vector position, uint32_t depth) {
        m_nodes[nodeId] = DAGNode(nodeId, position, depth);
        m_adjacencyList[nodeId] = std::vector<uint32_t>();
    }
    
    void AddEdge(uint32_t from, uint32_t to) {
        if (m_adjacencyList.find(from) != m_adjacencyList.end()) {
            m_adjacencyList[from].push_back(to);
            m_nodes[from].children.push_back(to);
            m_nodes[to].parents.push_back(from);
        }
    }
    
    // BFS-based path finding from any node to donor (root)
    std::vector<uint32_t> FindPathToDonor(uint32_t sourceNode) {
        std::vector<uint32_t> path;
        std::set<uint32_t> visited;
        std::map<uint32_t, uint32_t> parent;
        std::queue<uint32_t> queue;
        
        queue.push(sourceNode);
        visited.insert(sourceNode);
        parent[sourceNode] = sourceNode;
        
        while (!queue.empty()) {
            uint32_t current = queue.front();
            queue.pop();
            
            // Found donor (node 0)
            if (current == 0) {
                // Reconstruct path
                uint32_t node = current;
                while (node != sourceNode) {
                    path.push_back(node);
                    node = parent[node];
                }
                path.push_back(sourceNode);
                std::reverse(path.begin(), path.end());
                return path;
            }
            
            // Visit parents (upstream towards donor)
            for (uint32_t neighbor : m_nodes[current].parents) {
                if (visited.find(neighbor) == visited.end()) {
                    visited.insert(neighbor);
                    parent[neighbor] = current;
                    queue.push(neighbor);
                }
            }
        }
        
        return path; // Empty if no path found
    }
    
    // Find all possible paths from UE to Donor considering connection limits
    std::vector<std::vector<uint32_t>> FindAllPathsToDonor(uint32_t sourceNode) {
        std::vector<std::vector<uint32_t>> allPaths;
        std::vector<uint32_t> currentPath;
        std::set<uint32_t> visited;
        
        DFSPaths(sourceNode, 0, currentPath, visited, allPaths);
        return allPaths;
    }
    
    void DFSPaths(uint32_t current, uint32_t target, std::vector<uint32_t>& currentPath,
                 std::set<uint32_t>& visited, std::vector<std::vector<uint32_t>>& allPaths) {
        visited.insert(current);
        currentPath.push_back(current);
        
        if (current == target) {
            allPaths.push_back(currentPath);
        } else {
            for (uint32_t parent : m_nodes[current].parents) {
                if (visited.find(parent) == visited.end() && 
                    m_nodes[parent].currentConnections < m_nodes[parent].maxConnections) {
                    DFSPaths(parent, target, currentPath, visited, allPaths);
                }
            }
        }
        
        currentPath.pop_back();
        visited.erase(current);
    }
    
    // Get best path based on hop count and load balancing
    std::vector<uint32_t> GetBestPathToDonor(uint32_t sourceNode) {
        auto allPaths = FindAllPathsToDonor(sourceNode);
        if (allPaths.empty()) {
            return std::vector<uint32_t>();
        }
        
        // Select path with minimum hops and least loaded nodes
        std::vector<uint32_t> bestPath;
        double bestScore = std::numeric_limits<double>::max();
        
        for (const auto& path : allPaths) {
            double score = path.size(); // Hop count
            // Add load balancing factor
            for (uint32_t nodeId : path) {
                if (nodeId != 0) { // Don't count donor
                    score += m_nodes[nodeId].currentConnections * 0.1;
                }
            }
            
            if (score < bestScore) {
                bestScore = score;
                bestPath = path;
            }
        }
        
        return bestPath;
    }
    
    bool CanAcceptConnection(uint32_t nodeId) {
        if (m_nodes.find(nodeId) == m_nodes.end()) return false;
        return m_nodes[nodeId].currentConnections < m_nodes[nodeId].maxConnections;
    }
    
    void AddConnection(uint32_t nodeId) {
        if (m_nodes.find(nodeId) != m_nodes.end()) {
            m_nodes[nodeId].currentConnections++;
        }
    }
    
    void RemoveConnection(uint32_t nodeId) {
        if (m_nodes.find(nodeId) != m_nodes.end()) {
            if (m_nodes[nodeId].currentConnections > 0) {
                m_nodes[nodeId].currentConnections--;
            }
        }
    }
    
    Vector GetNodePosition(uint32_t nodeId) {
        if (m_nodes.find(nodeId) != m_nodes.end()) {
            return m_nodes[nodeId].position;
        }
        return Vector(0, 0, 0);
    }
    
    double CalculateDistance(uint32_t node1, uint32_t node2) {
        Vector pos1 = GetNodePosition(node1);
        Vector pos2 = GetNodePosition(node2);
        double dx = pos1.x - pos2.x;
        double dy = pos1.y - pos2.y;
        double dz = pos1.z - pos2.z;
        return sqrt(dx*dx + dy*dy + dz*dz);
    }
    
    void PrintTopology() {
        NS_LOG_INFO("DAG Topology:");
        for (const auto& pair : m_nodes) {
            const DAGNode& node = pair.second;
            NS_LOG_INFO("Node " << node.nodeId << " (Depth " << node.depth 
                       << ") - Parents: " << node.parents.size() 
                       << ", Children: " << node.children.size()
                       << ", Connections: " << node.currentConnections << "/" << node.maxConnections);
        }
    }
    
    const std::map<uint32_t, DAGNode>& GetNodes() const { return m_nodes; }
    
private:
    std::map<uint32_t, DAGNode> m_nodes;
    std::map<uint32_t, std::vector<uint32_t>> m_adjacencyList;
};

// Task structure for computation offloading
struct ComputationTask {
    uint32_t taskId;
    uint32_t ueId;
    uint32_t priority;
    double inputSize;
    uint32_t cpuCycles;
    double deadline;
    double outputSize;
    Time arrivalTime;
    Ipv4Address ueAddress;
    uint32_t attachedIabNode; // Which IAB node this UE is attached to
    
    ComputationTask(uint32_t id, uint32_t ue, uint32_t pri, double input, uint32_t cycles, 
                   double dead, double output, Ipv4Address addr, uint32_t iabNode)
        : taskId(id), ueId(ue), priority(pri), inputSize(input), cpuCycles(cycles),
          deadline(dead), outputSize(output), ueAddress(addr), attachedIabNode(iabNode) {
        arrivalTime = Simulator::Now();
    }
};

// Enhanced Statistics structure with link state tracking
struct TaskStatistics {
    uint32_t totalTasks = 0;
    uint32_t offloadedTasks = 0;
    uint32_t localTasks = 0;
    uint32_t preemptedTasks = 0;
    uint32_t deadlineViolations = 0;
    uint32_t tasksByPriority[3] = {0, 0, 0};
    uint32_t offloadedByPriority[3] = {0, 0, 0};
    double totalUplinkTime = 0;
    double totalDownlinkTime = 0;
    double totalProcessingTime = 0;
    uint32_t networkBottleneckTasks = 0;
    double totalOffloadEnergy = 0;
    double totalLocalEnergy = 0;
    
    // Multihop specific stats
    uint32_t totalHops = 0;
    uint32_t singleHopTasks = 0;
    uint32_t twoHopTasks = 0;
    uint32_t threeHopTasks = 0;
    std::map<uint32_t, uint32_t> pathUtilization; // Path usage count
    
    // Link state statistics
    uint32_t losLinksUsed = 0;
    uint32_t nlosLinksUsed = 0;
    uint32_t blockedLinksEncountered = 0;
    uint32_t tasksReroutedDueToBlockage = 0;
    double averageLOSDataRate = 0;
    double averageNLOSDataRate = 0;
};

// Custom packet header for task requests (modified for multihop)
class TaskRequestHeader : public Header {
public:
    TaskRequestHeader() : m_hops(0) {}
    
    void SetTask(const ComputationTask& task, const std::vector<uint32_t>& path) {
        m_taskId = task.taskId;
        m_ueId = task.ueId;
        m_priority = task.priority;
        m_inputSize = task.inputSize;
        m_cpuCycles = task.cpuCycles;
        m_deadline = task.deadline;
        m_outputSize = task.outputSize;
        m_path = path;
        m_hops = path.size() - 1;
    }
    
    ComputationTask GetTask(Ipv4Address ueAddr, uint32_t iabNode) const {
        return ComputationTask(m_taskId, m_ueId, m_priority, m_inputSize, 
                              m_cpuCycles, m_deadline, m_outputSize, ueAddr, iabNode);
    }
    
    const std::vector<uint32_t>& GetPath() const { return m_path; }
    uint32_t GetHopCount() const { return m_hops; }
    
    static TypeId GetTypeId() {
        static TypeId tid = TypeId("TaskRequestHeader")
            .SetParent<Header>()
            .AddConstructor<TaskRequestHeader>();
        return tid;
    }
    
    virtual TypeId GetInstanceTypeId() const { return GetTypeId(); }
    virtual void Print(std::ostream &os) const { os << "TaskRequest(Hops: " << m_hops << ")"; }
    virtual uint32_t GetSerializedSize() const { return 36 + m_path.size() * 4; }
    
    virtual void Serialize(Buffer::Iterator start) const {
        start.WriteHtonU32(m_taskId);
        start.WriteHtonU32(m_ueId);
        start.WriteHtonU32(m_priority);
        start.WriteHtonU32((uint32_t)(m_inputSize * 1000000));
        start.WriteHtonU32(m_cpuCycles);
        start.WriteHtonU32((uint32_t)(m_deadline * 1000));
        start.WriteHtonU32((uint32_t)(m_outputSize * 1000000));
        start.WriteHtonU32(m_hops);
        start.WriteHtonU32(m_path.size());
        
        for (uint32_t node : m_path) {
            start.WriteHtonU32(node);
        }
    }
    
    virtual uint32_t Deserialize(Buffer::Iterator start) {
        m_taskId = start.ReadNtohU32();
        m_ueId = start.ReadNtohU32();
        m_priority = start.ReadNtohU32();
        m_inputSize = start.ReadNtohU32() / 1000000.0;
        m_cpuCycles = start.ReadNtohU32();
        m_deadline = start.ReadNtohU32() / 1000.0;
        m_outputSize = start.ReadNtohU32() / 1000000.0;
        m_hops = start.ReadNtohU32();
        uint32_t pathSize = start.ReadNtohU32();
        
        m_path.clear();
        for (uint32_t i = 0; i < pathSize; i++) {
            m_path.push_back(start.ReadNtohU32());
        }
        
        return GetSerializedSize();
    }
    
private:
    uint32_t m_taskId;
    uint32_t m_ueId;
    uint32_t m_priority;
    double m_inputSize;
    uint32_t m_cpuCycles;
    double m_deadline;
    double m_outputSize;
    uint32_t m_hops;
    std::vector<uint32_t> m_path;
};

// UE Task Generator Application (modified for DAG)
class UeTaskGeneratorApplication : public Application {
public:
    static TypeId GetTypeId() {
        static TypeId tid = TypeId("UeTaskGeneratorApplication")
            .SetParent<Application>()
            .AddConstructor<UeTaskGeneratorApplication>();
        return tid;
    }
    
    UeTaskGeneratorApplication() : m_socket(0), m_taskCounter(0), m_ueId(0), m_attachedIabNode(0) {}
    
    void Setup(Ipv4Address schedulerAddress, uint16_t port, uint32_t ueId, uint32_t iabNode, Ptr<DAGTopology> dagTopology) {
        m_schedulerAddress = schedulerAddress;
        m_schedulerPort = port;
        m_ueId = ueId;
        m_attachedIabNode = iabNode;
        m_dagTopology = dagTopology;
    }
    
private:
    virtual void StartApplication() {
        m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
        m_socket->SetRecvCallback(MakeCallback(&UeTaskGeneratorApplication::HandleRead, this));
        m_socket->Bind();
        
        ScheduleNextTask();
        
        NS_LOG_INFO("UE " << m_ueId << " attached to IAB " << m_attachedIabNode 
                   << " started at " << Simulator::Now().GetSeconds() << "s");
    }
    
    virtual void StopApplication() {
        if (m_socket) {
            m_socket->Close();
        }
    }
    
    void ScheduleNextTask() {
        double arrivalRate;
        // Updated for 40 UEs - reduced arrival rates to prevent overload
        if (m_ueId < 10) arrivalRate = 12; 
        else if (m_ueId < 20) arrivalRate = 14;
        else if (m_ueId < 30) arrivalRate = 16;
        else arrivalRate = 8;
        
        std::exponential_distribution<double> dist(arrivalRate);
        std::random_device rd;
        std::mt19937 gen(rd() + m_ueId + static_cast<unsigned>(Simulator::Now().GetNanoSeconds()));
        double nextTime = dist(gen);
        
        if (Simulator::Now().GetSeconds() + nextTime < 14.0) {
            Simulator::Schedule(Seconds(nextTime), &UeTaskGeneratorApplication::GenerateTask, this);
        }
    }
    
    void GenerateTask() {
        std::random_device rd;
        std::mt19937 gen(rd() + m_ueId + m_taskCounter + static_cast<unsigned>(Simulator::Now().GetNanoSeconds()));
        
        uint32_t priority;
        double inputSize, deadline, outputSize;
        uint32_t cpuCycles;
        
        // Task generation logic - updated for 40 UEs
        if (m_ueId < 10) {
            priority = 1;
            double sizeChoice = std::uniform_real_distribution<>(0.0, 1.0)(gen);
            if (sizeChoice < 0.1) {
                std::uniform_real_distribution<> sizeDist(0.005, 0.02);
                inputSize = sizeDist(gen);
            } else if (sizeChoice < 0.4) {
                std::uniform_real_distribution<> sizeDist(0.03, 0.1);
                inputSize = sizeDist(gen);
            } else {
                std::uniform_real_distribution<> sizeDist(0.15, 0.3);
                inputSize = sizeDist(gen);
            }
            cpuCycles = (uint32_t)(inputSize * 80000 * 1000);
            std::uniform_real_distribution<> deadlineDist(50, 150);
            deadline = deadlineDist(gen);
            outputSize = inputSize * 0.05;
            
        } else if (m_ueId < 25) {
            priority = 2;
            double sizeChoice = std::uniform_real_distribution<>(0.0, 1.0)(gen);
            if (sizeChoice < 0.1) {
                std::uniform_real_distribution<> sizeDist(0.1, 0.5);
                inputSize = sizeDist(gen);
            } else if (sizeChoice < 0.4) {
                std::uniform_real_distribution<> sizeDist(1.0, 5.0);
                inputSize = sizeDist(gen);
            } else {
                std::uniform_real_distribution<> sizeDist(5.0, 25.0);
                inputSize = sizeDist(gen);
            }
            cpuCycles = (uint32_t)(inputSize * 25000 * 1000);
            std::uniform_real_distribution<> deadlineDist(200, 800);
            deadline = deadlineDist(gen);
            outputSize = inputSize * 0.2;
            
        } else {
            priority = 3;
            double sizeChoice = std::uniform_real_distribution<>(0.0, 1.0)(gen);
            if (sizeChoice < 0.1) {
                std::uniform_real_distribution<> sizeDist(0.0005, 0.005);
                inputSize = sizeDist(gen);
            } else if (sizeChoice < 0.4) {
                std::uniform_real_distribution<> sizeDist(0.02, 0.1);
                inputSize = sizeDist(gen);
            } else {
                std::uniform_real_distribution<> sizeDist(0.3, 2.0);
                inputSize = sizeDist(gen);
            }
            double complexityMultiplier = (sizeChoice < 0.7) ? 3000 : 10000;
            cpuCycles = (uint32_t)(inputSize * complexityMultiplier * 1000);
            std::uniform_real_distribution<> deadlineDist(100, 2000);
            deadline = deadlineDist(gen);
            outputSize = inputSize * 0.02;
        }
        
        Ipv4Address myAddress = GetNode()->GetObject<Ipv4>()->GetAddress(1, 0).GetLocal();
        ComputationTask task(m_taskCounter++, m_ueId, priority, inputSize, 
                           cpuCycles, deadline, outputSize, myAddress, m_attachedIabNode);
        
        SendTaskRequest(task);
        ScheduleNextTask();
    }
    
    void SendTaskRequest(const ComputationTask& task) {
        Ptr<Packet> packet = Create<Packet>(100);
        TaskRequestHeader header;
        
        // Find path through DAG
        auto path = m_dagTopology->GetBestPathToDonor(m_attachedIabNode);
        
        if (path.empty()) {
            NS_LOG_WARN("UE " << m_ueId << ": No path to donor found!");
            return;
        }
        
        header.SetTask(task, path);
        packet->AddHeader(header);
        
        m_socket->SendTo(packet, 0, InetSocketAddress(m_schedulerAddress, m_schedulerPort));
        
        NS_LOG_INFO("UE " << m_ueId << " via IAB " << m_attachedIabNode 
                   << " sent task " << task.taskId << " through " << (path.size()-1) << " hops");
    }
    
    void HandleRead(Ptr<Socket> socket) {
        Ptr<Packet> packet;
        Address from;
        while ((packet = socket->RecvFrom(from))) {
            // Handle responses if needed
        }
    }
    
    Ptr<Socket> m_socket;
    Ipv4Address m_schedulerAddress;
    uint16_t m_schedulerPort;
    uint32_t m_taskCounter;
    uint32_t m_ueId;
    uint32_t m_attachedIabNode;
    Ptr<DAGTopology> m_dagTopology;
};

// Central Scheduler Application with Enhanced NLOS/LOS Modeling
class CentralSchedulerApplication : public Application {
public:
    static TypeId GetTypeId() {
        static TypeId tid = TypeId("CentralSchedulerApplication")
            .SetParent<Application>()
            .AddConstructor<CentralSchedulerApplication>();
        return tid;
    }
    
    CentralSchedulerApplication() : m_socket(0), m_mecCapacity(20),
                              m_mecFrequency(3e9), m_uplinkRate(1.5e9), m_downlinkRate(1e9),
                              m_transmitPower(0.5), m_ueFrequency(1e9), m_kappa(1e-27) {
        // Initialize mmWave parameters with default values
        SetMmWaveParameters();

        m_maxQueueSize = 10;
        m_processingTask = false;
        m_currentCPUEfficiency = 1.0;
        
        // Create link state manager
        m_linkStateManager = CreateObject<LinkStateManager>();
    }
    
    void Setup(uint16_t port, Ptr<DAGTopology> dagTopology) {
        m_port = port;
        m_dagTopology = dagTopology;
    }
    
    // Add these public methods for parameter configuration
    void SetMmWaveParameters() {
        // mmWave frequency band (28 GHz)
        m_carrierFrequency = 28e9; // 28 GHz
        
        // Noise figures (dB)
        m_ueNoiseFigure = 7.0;    // UE receiver noise figure
        m_gnbNoiseFigure = 5.0;   // gNB/IAB noise figure
        
        // Transmit powers (dBm)
        m_ueTxPower = 23.0;       // UE TX power (23 dBm = 200 mW)
        m_iabTxPower = 30.0;      // IAB node TX power (30 dBm = 1W)
        m_donorTxPower = 35.0;    // Donor TX power (35 dBm = 3.2W)
        
        // Antenna gains (dBi)
        m_ueAntennaGain = 0.0;    // UE antenna gain
        m_iabAntennaGain = 25.0;  // IAB antenna gain (beamforming)
        m_donorAntennaGain = 25.0; // Donor antenna gain
        
        NS_LOG_INFO("mmWave Parameters: Freq=" << m_carrierFrequency/1e9 << "GHz, "
                   << "UE_TX=" << m_ueTxPower << "dBm, IAB_TX=" << m_iabTxPower << "dBm");
    }
    
    void SetCarrierFrequency(double freqGHz) { m_carrierFrequency = freqGHz * 1e9; }
    void SetUeTxPower(double powerDbm) { m_ueTxPower = powerDbm; }
    void SetIabTxPower(double powerDbm) { m_iabTxPower = powerDbm; }
    void SetDonorTxPower(double powerDbm) { m_donorTxPower = powerDbm; }

private:
    struct QueuedTask {
        ComputationTask task;
        Time arrivalTime;
        Time startProcessingTime;
        uint32_t hopCount;
        std::vector<uint32_t> path;
        
        QueuedTask(const ComputationTask& t, uint32_t hops, const std::vector<uint32_t>& p)
            : task(t), arrivalTime(Simulator::Now()), hopCount(hops), path(p) {}
    };
    
    std::queue<QueuedTask> m_taskQueue;
    uint32_t m_maxQueueSize;
    bool m_processingTask;
    double m_currentCPUEfficiency; // 1.0 = full performance, 0.8 = 20% drop
    std::vector<ComputationTask> m_activeTasks;
    Ptr<LinkStateManager> m_linkStateManager;
    
    // Add these methods for queue management
    void InitializeQueueSystem() {
        m_maxQueueSize = 10; // Allow 10 tasks to queue
        m_processingTask = false;
        m_currentCPUEfficiency = 1.0; // Start at full performance
        
        NS_LOG_INFO("MEC Queue System: MaxQueue=" << m_maxQueueSize 
                   << ", CPU Efficiency starts at " << m_currentCPUEfficiency * 100 << "%");
    }
    

    // Queue management methods
    void UpdateCPUEfficiency() {
        double loadFactor = (double)(m_activeTasks.size() + m_taskQueue.size()) / m_mecCapacity;
        
        if (loadFactor >= 1.0) {
            m_currentCPUEfficiency = 0.8; // 20% performance drop
        } else if (loadFactor >= 0.8) {
            m_currentCPUEfficiency = 0.8 + (1.0 - 0.8) * ((1.0 - loadFactor) / 0.2);
        } else {
            m_currentCPUEfficiency = 1.0;
        }
        
        NS_LOG_DEBUG("CPU Efficiency: Active=" << m_activeTasks.size() 
                    << ", Queued=" << m_taskQueue.size() 
                    << ", Efficiency=" << m_currentCPUEfficiency * 100 << "%");
    }
    
    double GetEffectiveProcessingTime(const ComputationTask& task) {
        double baseProcessingTime = task.cpuCycles / m_mecFrequency * 1000;
        return baseProcessingTime / m_currentCPUEfficiency;
    }
    
    double GetQueueWaitingTime() {
        if (m_taskQueue.empty() && !m_processingTask) {
            return 0.0;
        }
        double avgProcessingTime = 50.0;
        return m_taskQueue.size() * avgProcessingTime;
    }
    
    void ProcessNextTask() {
        if (m_taskQueue.empty()) {
            m_processingTask = false;
            return;
        }
        
        m_processingTask = true;
        QueuedTask queuedTask = m_taskQueue.front();
        m_taskQueue.pop();
        
        queuedTask.startProcessingTime = Simulator::Now();
        double queueWaitTime = (queuedTask.startProcessingTime - queuedTask.arrivalTime).GetMilliSeconds();
        double processingTime = GetEffectiveProcessingTime(queuedTask.task);
        
        NS_LOG_INFO("MEC Processing: Task " << queuedTask.task.taskId 
                   << " started after " << queueWaitTime << "ms queue wait"
                   << ", processing=" << processingTime << "ms");
        
        Simulator::Schedule(MilliSeconds(processingTime), 
                          &CentralSchedulerApplication::CompleteTask, this, queuedTask.task.taskId);
    }


    virtual void StartApplication() {
        m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
        m_socket->Bind(InetSocketAddress(Ipv4Address::GetAny(), m_port));
        m_socket->SetRecvCallback(MakeCallback(&CentralSchedulerApplication::HandleTaskRequest, this));
    
        // Initialize the queue system
        InitializeQueueSystem();
    
        NS_LOG_INFO("*** Central Scheduler started - DAG MULTIHOP NETWORK ***");
        NS_LOG_INFO("*** ENHANCED WITH REALISTIC NLOS/LOS mmWave CHANNEL MODEL ***");
        NS_LOG_INFO("*** SCALED CONFIGURATION: 40 UEs, MEC Capacity=20, Queue Size=10 ***");
        NS_LOG_INFO("*** 9-Node DAG Topology with Multihop Routing ***");
        NS_LOG_INFO("*** mmWave Channel: " << m_carrierFrequency/1e9 << "GHz, UMi Path Loss ***");
        NS_LOG_INFO("*** MEC Server: Capacity=" << m_mecCapacity << ", MaxQueue=" << m_maxQueueSize << " ***");
        NS_LOG_INFO("*** Link States: Dynamic LOS/NLOS/Blocked conditions ***");
        m_dagTopology->PrintTopology();
    
        m_taskLog.open("task_metrics_multihop_enhanced.csv");
        m_taskLog << "task_id,ue_id,priority,decision,hops,uplink_ms,processing_ms,downlink_ms,total_offload_ms,local_ms,deadline_ms,met_deadline,energy_offload,energy_local,path,sinr_dB,data_rate_mbps,queue_wait_ms,cpu_efficiency,link_state,blocked_hops\n";
        
        // Schedule periodic link state logging
        Simulator::Schedule(Seconds(2.0), &CentralSchedulerApplication::LogLinkStates, this);
    }
    
    virtual void StopApplication() {
        if (m_socket) {
            m_socket->Close();
        }
        
        // Enhanced statistics for multihop with link states
        NS_LOG_INFO("=== DAG MULTIHOP SIMULATION RESULTS ===");
        NS_LOG_INFO("Total tasks: " << m_stats.totalTasks);
        NS_LOG_INFO("Offloaded: " << m_stats.offloadedTasks << " (" 
                   << (m_stats.offloadedTasks * 100.0 / m_stats.totalTasks) << "%)");
        NS_LOG_INFO("Local: " << m_stats.localTasks << " (" 
                   << (m_stats.localTasks * 100.0 / m_stats.totalTasks) << "%)");
        NS_LOG_INFO("Average hops per offloaded task: " 
                   << (m_stats.offloadedTasks > 0 ? (double)m_stats.totalHops / m_stats.offloadedTasks : 0));
        NS_LOG_INFO("Single-hop tasks: " << m_stats.singleHopTasks);
        NS_LOG_INFO("Two-hop tasks: " << m_stats.twoHopTasks);
        NS_LOG_INFO("Three-hop tasks: " << m_stats.threeHopTasks);
        
        // Link state statistics
        NS_LOG_INFO("=== LINK STATE STATISTICS ===");
        NS_LOG_INFO("LOS links used: " << m_stats.losLinksUsed);
        NS_LOG_INFO("NLOS links used: " << m_stats.nlosLinksUsed);
        NS_LOG_INFO("Blocked links encountered: " << m_stats.blockedLinksEncountered);
        NS_LOG_INFO("Tasks rerouted due to blockage: " << m_stats.tasksReroutedDueToBlockage);
        NS_LOG_INFO("Average LOS data rate: " << m_stats.averageLOSDataRate << " Mbps");
        NS_LOG_INFO("Average NLOS data rate: " << m_stats.averageNLOSDataRate << " Mbps");
        
        // Path utilization
        NS_LOG_INFO("Path Utilization:");
        for (const auto& pair : m_stats.pathUtilization) {
            NS_LOG_INFO("  Path ending at IAB " << pair.first << ": " << pair.second << " tasks");
        }
        
        // mmWave performance stats
        NS_LOG_INFO("Average uplink time: " << (m_stats.offloadedTasks > 0 ? m_stats.totalUplinkTime / m_stats.offloadedTasks : 0) << "ms");
        NS_LOG_INFO("Average processing time: " << (m_stats.offloadedTasks > 0 ? m_stats.totalProcessingTime / m_stats.offloadedTasks : 0) << "ms");
        NS_LOG_INFO("Average downlink time: " << (m_stats.offloadedTasks > 0 ? m_stats.totalDownlinkTime / m_stats.offloadedTasks : 0) << "ms");
        
        if (m_taskLog.is_open()) m_taskLog.close();
    }
    
    void LogLinkStates() {
        m_linkStateManager->PrintLinkStates();
        if (Simulator::Now().GetSeconds() < 13.0) {
            Simulator::Schedule(Seconds(2.0), &CentralSchedulerApplication::LogLinkStates, this);
        }
    }
    
    void HandleTaskRequest(Ptr<Socket> socket) {
        Ptr<Packet> packet;
        Address from;
        while ((packet = socket->RecvFrom(from))) {
            TaskRequestHeader header;
            packet->RemoveHeader(header);
            
            InetSocketAddress inetFrom = InetSocketAddress::ConvertFrom(from);
            ComputationTask task = header.GetTask(inetFrom.GetIpv4(), header.GetPath().back());
            
            m_stats.totalTasks++;
            
            // Track path usage
            uint32_t entryIab = header.GetPath().back();
            m_stats.pathUtilization[entryIab]++;
            
            NS_LOG_INFO("*** Received task " << task.taskId << " from UE " << task.ueId
                       << " via IAB " << task.attachedIabNode << " (" << header.GetHopCount() << " hops) ***");
            
            auto decision = MakeHybridDecision(task, header.GetPath(), header.GetHopCount());
            std::string decisionStr = decision.first;
            std::string reason = decision.second;
            
            Ptr<Packet> response = Create<Packet>((uint8_t*)decisionStr.c_str(), decisionStr.length());
            socket->SendTo(response, 0, from);
        }
    }
    
    void CompleteTask(uint32_t taskId) {
        auto it = std::find_if(m_activeTasks.begin(), m_activeTasks.end(),
            [taskId](const ComputationTask& task) { return task.taskId == taskId; });
    
        if (it != m_activeTasks.end()) {
            NS_LOG_INFO("MEC Completed: Task " << taskId << " finished processing");
            m_activeTasks.erase(it);
        
            // Update CPU efficiency after task completion
            UpdateCPUEfficiency();
        
            // Process next task in queue
            ProcessNextTask();
        }
    }
    
    // Enhanced mmWave Channel Modeling Methods with NLOS/LOS
    double CalculatePathLoss(double distance, LinkStateManager::LinkState linkState) {
        double fc_ghz = m_carrierFrequency / 1e9; // Frequency in GHz
        double h_UT = 1.5;  // UE height in meters
        double h_BS = 10.0; // BS height in meters
        
        double basePathLoss;
        
        if (linkState == LinkStateManager::LOS) {
            // LOS path loss
            if (distance <= 18.0) {
                basePathLoss = 32.4 + 21.0 * log10(distance) + 20.0 * log10(fc_ghz);
            } else {
                double PL1 = 32.4 + 21.0 * log10(18.0) + 20.0 * log10(fc_ghz);
                double PL2 = 32.4 + 40.0 * log10(distance) + 20.0 * log10(fc_ghz) 
                           - 9.5 * log10(18.0 * 18.0 + (h_BS - h_UT) * (h_BS - h_UT));
                basePathLoss = std::max(PL1, PL2);
            }
        } else {
            // NLOS path loss
            basePathLoss = 35.3 * log10(distance) + 22.4 + 21.3 * log10(fc_ghz) 
                         - 0.3 * (h_UT - 1.5);
            
            // Add additional loss based on link state
            basePathLoss += m_linkStateManager->GetAdditionalLoss(linkState);
        }
        
        return basePathLoss;
    }
    
    double CalculateSINR(double txPower, double txGain, double rxGain, 
                        double distance, double rxNoiseFigure, LinkStateManager::LinkState linkState) {
        // Calculate received power
        double pathLoss = CalculatePathLoss(distance, linkState);
        double receivedPower = txPower + txGain + rxGain - pathLoss;
        
        // Calculate noise power
        double thermalNoise = -174.0; // dBm/Hz
        double bandwidth = 400e6;     // 400 MHz
        double noisePower = thermalNoise + 10 * log10(bandwidth) + rxNoiseFigure;
        
        // SINR (assuming no interference for now)
        double sinr = receivedPower - noisePower;
        
        NS_LOG_DEBUG("SINR Calc: TX=" << txPower << "dBm, PL=" << pathLoss 
                    << "dB, RX=" << receivedPower << "dBm, Noise=" << noisePower 
                    << "dBm, SINR=" << sinr << "dB, State=" 
                    << (linkState == LinkStateManager::LOS ? "LOS" : 
                       (linkState == LinkStateManager::NLOS ? "NLOS" : "BLOCKED")));
        
        return sinr;
    }
    
    double CalculateDataRate(double sinrDb) {
        // Convert SINR from dB to linear
        double sinrLinear = pow(10.0, sinrDb / 10.0);
        
        // Shannon capacity with efficiency factor (typically 0.6-0.8 for real systems)
        double bandwidth = 400e6; // 400 MHz
        double efficiency = 0.7;  // 70% efficiency
        
        double dataRate = bandwidth * log2(1 + sinrLinear) * efficiency;
        
        NS_LOG_DEBUG("Data Rate: SINR=" << sinrDb << "dB -> " << dataRate/1e6 << " Mbps");
        
        return dataRate;
    }
    
    double CalculateDistance(const Vector& a, const Vector& b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        double dz = a.z - b.z;
        return sqrt(dx*dx + dy*dy + dz*dz);
    }
    
    // Enhanced decision method with realistic mmWave timing and link states
    std::pair<std::string, std::string> MakeHybridDecision(const ComputationTask& task, 
                                                          const std::vector<uint32_t>& path, 
                                                          uint32_t hopCount) {
        m_stats.tasksByPriority[task.priority-1]++;
        
        // REALISTIC MULTIHOP TIMING CALCULATION with dynamic link states
        double totalUplinkTime = 0;
        double totalDownlinkTime = 0;
        double worstCaseSinr = 100.0; // Initialize with high value
        double worstCaseDataRate = 0;
        uint32_t blockedHops = 0;
        std::string linkStateSummary = "";
        
        // Calculate realistic transmission times for each hop with current link states
        for (uint32_t i = 0; i < hopCount; i++) {
            uint32_t txNode = path[i];
            uint32_t rxNode = path[i+1];
            
            // Get node positions and calculate distance
            Vector txPos = m_dagTopology->GetNodePosition(txNode);
            Vector rxPos = m_dagTopology->GetNodePosition(rxNode);
            double distance = CalculateDistance(txPos, rxPos);
            
            // Get current link state
            LinkStateManager::LinkState linkState = m_linkStateManager->GetLinkState(txNode, rxNode, distance);
            
            // Track link state statistics
            if (linkState == LinkStateManager::LOS) {
                m_stats.losLinksUsed++;
                linkStateSummary += "LOS-";
            } else if (linkState == LinkStateManager::NLOS) {
                m_stats.nlosLinksUsed++;
                linkStateSummary += "NLOS-";
            } else {
                m_stats.blockedLinksEncountered++;
                blockedHops++;
                linkStateSummary += "BLOCKED-";
            }
            
            // If link is blocked, this path is not feasible
            if (linkState == LinkStateManager::BLOCKED) {
                NS_LOG_WARN("Path contains blocked link: " << txNode << "->" << rxNode);
                totalUplinkTime = 1e6; // Large penalty
                totalDownlinkTime = 1e6;
                break;
            }
            
            // Determine TX power and gains based on node type
            double txPower, txGain, rxGain, rxNoiseFigure;
            if (txNode == 0) { // Donor
                txPower = m_donorTxPower;
                txGain = m_donorAntennaGain;
            } else { // IAB node
                txPower = m_iabTxPower;
                txGain = m_iabAntennaGain;
            }
            
            if (rxNode == 0) { // Donor
                rxGain = m_donorAntennaGain;
                rxNoiseFigure = m_gnbNoiseFigure;
            } else { // IAB node
                rxGain = m_iabAntennaGain;
                rxNoiseFigure = m_gnbNoiseFigure;
            }
            
            // Calculate SINR and data rate for this hop with current link state
            double sinr = CalculateSINR(txPower, txGain, rxGain, distance, rxNoiseFigure, linkState);
            double dataRate = CalculateDataRate(sinr);
            
            // Track worst-case SINR and data rate for logging
            if (sinr < worstCaseSinr) {
                worstCaseSinr = sinr;
                worstCaseDataRate = dataRate;
            }
            
            // Track average data rates by link state
            if (linkState == LinkStateManager::LOS) {
                m_stats.averageLOSDataRate = (m_stats.averageLOSDataRate * (m_stats.losLinksUsed - 1) + dataRate/1e6) / m_stats.losLinksUsed;
            } else {
                m_stats.averageNLOSDataRate = (m_stats.averageNLOSDataRate * (m_stats.nlosLinksUsed - 1) + dataRate/1e6) / m_stats.nlosLinksUsed;
            }
            
            // Calculate transmission time for this hop
            double hopUplinkTime = (task.inputSize * 8e6) / dataRate * 1000; // ms
            double hopDownlinkTime = (task.outputSize * 8e6) / dataRate * 1000; // ms
            
            totalUplinkTime += hopUplinkTime;
            totalDownlinkTime += hopDownlinkTime;
            
            NS_LOG_DEBUG("Hop " << i << ": " << txNode << "->" << rxNode 
                        << ", dist=" << distance << "m, State=" 
                        << (linkState == LinkStateManager::LOS ? "LOS" : "NLOS")
                        << ", SINR=" << sinr << "dB, rate=" << dataRate/1e6 
                        << "Mbps, UL_time=" << hopUplinkTime << "ms");
        }
        
        // Remove trailing dash from link state summary
        if (!linkStateSummary.empty()) {
            linkStateSummary.pop_back();
        }
        
        // Add processing delays (2ms per hop as before)
        double perHopProcessingDelay = 2.0; // ms
        totalUplinkTime += hopCount * perHopProcessingDelay;
        totalDownlinkTime += hopCount * perHopProcessingDelay;
        
        double mecProcessingTime = task.cpuCycles / m_mecFrequency * 1000;
        double localProcessingTime = task.cpuCycles / m_ueFrequency * 1000;
        
        double totalOffloadTime = totalUplinkTime + mecProcessingTime + totalDownlinkTime;
        double totalLocalTime = localProcessingTime;
        
        // Energy calculations (multihop increases transmission energy)
        double offloadEnergy = m_transmitPower * (totalUplinkTime / 1000.0) * (1 + 0.1 * hopCount);
        double localEnergy = m_kappa * m_ueFrequency * m_ueFrequency * task.cpuCycles;
        
        // If path has blocked links, try to find alternative path
        if (blockedHops > 0) {
            m_stats.tasksReroutedDueToBlockage++;
            NS_LOG_WARN("Task " << task.taskId << " has " << blockedHops << " blocked hops, finding alternative path");
            
            // Try to find alternative path
            auto alternativePath = m_dagTopology->GetBestPathToDonor(task.attachedIabNode);
            if (!alternativePath.empty() && alternativePath != path) {
                NS_LOG_INFO("Found alternative path for task " << task.taskId);
                return MakeHybridDecision(task, alternativePath, alternativePath.size() - 1);
            }
        }
        
        // Weighted decision
        double alpha, beta;
        if (task.priority == 1) {
            alpha = 0.2; beta = 0.8;
        } else if (task.priority == 2) {
            alpha = 0.5; beta = 0.5;
        } else {
            alpha = 0.7; beta = 0.3;
        }
        
        double mecLoadFactor = (double)m_activeTasks.size() / m_mecCapacity;
        if (mecLoadFactor > 0.8) {
            alpha *= 0.7; beta *= 1.3;
        } else if (mecLoadFactor < 0.3) {
            alpha *= 1.3; beta *= 0.7;
        }
        
        double weightSum = alpha + beta;
        alpha /= weightSum;
        beta /= weightSum;
        
        double offloadCost = alpha * offloadEnergy + beta * totalOffloadTime;
        double localCost = alpha * localEnergy + beta * totalLocalTime;
        
        NS_LOG_INFO("Task " << task.taskId << " - Enhanced Multihop Analysis:");
        NS_LOG_INFO("  Hops: " << hopCount << ", Path: " << FormatPath(path));
        NS_LOG_INFO("  Link States: " << linkStateSummary << ", Blocked hops: " << blockedHops);
        NS_LOG_INFO("  Worst SINR: " << worstCaseSinr << "dB, Data Rate: " << worstCaseDataRate/1e6 << "Mbps");
        NS_LOG_INFO("  Offload: " << offloadEnergy << "J + " << totalOffloadTime << "ms = " << offloadCost);
        NS_LOG_INFO("  Local: " << localEnergy << "J + " << totalLocalTime << "ms = " << localCost);
        
        // Decision logic
        if (totalOffloadTime > task.deadline && totalLocalTime > task.deadline) {
            m_stats.deadlineViolations++;
            m_stats.localTasks++;
            LogTaskDecision(task, "EXECUTE_LOCALLY", totalUplinkTime, mecProcessingTime, 
                          totalDownlinkTime, totalOffloadTime, totalLocalTime, offloadEnergy, 
                          localEnergy, false, hopCount, path, "Both miss deadline", 
                          worstCaseSinr, worstCaseDataRate, 0.0, linkStateSummary, blockedHops);
            m_stats.totalLocalEnergy += localEnergy;
            return {"EXECUTE_LOCALLY", "Both exceed deadline"};
        }
        
        if (totalOffloadTime > task.deadline || blockedHops > 0) {
            m_stats.localTasks++;
            bool meetsDeadline = totalLocalTime <= task.deadline;
            if (!meetsDeadline) m_stats.deadlineViolations++;
            std::string reason = blockedHops > 0 ? "Blocked links in path" : "Offload misses deadline";
            LogTaskDecision(task, "EXECUTE_LOCALLY", totalUplinkTime, mecProcessingTime, 
                          totalDownlinkTime, totalOffloadTime, totalLocalTime, offloadEnergy, 
                          localEnergy, meetsDeadline, hopCount, path, reason, 
                          worstCaseSinr, worstCaseDataRate, 0.0, linkStateSummary, blockedHops);
            m_stats.totalLocalEnergy += localEnergy;
            return {"EXECUTE_LOCALLY", reason};
        }
        
        double costAdvantage = localCost - offloadCost;
        double decisionThreshold = 5.0;
        
        if (costAdvantage > decisionThreshold) {
            if (m_activeTasks.size() < m_mecCapacity) {
                return OffloadTask(task, totalUplinkTime, mecProcessingTime, totalDownlinkTime, 
                                 totalOffloadTime, totalLocalTime, offloadEnergy, localEnergy,
                                 hopCount, path, "Weighted sum favors offload", 
                                 worstCaseSinr, worstCaseDataRate, linkStateSummary, blockedHops);
            }
        }
        
        // Default to local execution
        m_stats.localTasks++;
        std::string reason = (costAdvantage <= decisionThreshold) ? 
            "Insufficient cost advantage" : "Cannot offload (MEC full)";
            
        LogTaskDecision(task, "EXECUTE_LOCALLY", totalUplinkTime, mecProcessingTime, 
                      totalDownlinkTime, totalOffloadTime, totalLocalTime, offloadEnergy, 
                      localEnergy, true, hopCount, path, reason, 
                      worstCaseSinr, worstCaseDataRate, 0.0, linkStateSummary, blockedHops);
        m_stats.totalLocalEnergy += localEnergy;
        return {"EXECUTE_LOCALLY", reason};
    }
    
    std::pair<std::string, std::string> OffloadTask(const ComputationTask& task,
                                               double uplinkTime, double processingTime, double downlinkTime,
                                               double totalOffloadTime, double localTime,
                                               double offloadEnergy, double localEnergy,
                                               uint32_t hopCount, const std::vector<uint32_t>& path,
                                               const std::string& reason, double sinr, double dataRate,
                                               const std::string& linkStateSummary, uint32_t blockedHops) {
    
        // Update CPU efficiency based on current load
        UpdateCPUEfficiency();
    
        // Check if we need to queue the task
        if (m_activeTasks.size() >= m_mecCapacity) {
            if (m_taskQueue.size() < m_maxQueueSize) {
                // Add to queue instead of rejecting
                QueuedTask queuedTask(task, hopCount, path);
                m_taskQueue.push(queuedTask);
            
                m_stats.offloadedTasks++;
                m_stats.offloadedByPriority[task.priority-1]++;
                m_stats.totalHops += hopCount;
            
                if (hopCount == 1) m_stats.singleHopTasks++;
                else if (hopCount == 2) m_stats.twoHopTasks++;
                else if (hopCount == 3) m_stats.threeHopTasks++;
            
                // Track statistics (we'll log when it actually starts processing)
                m_stats.totalUplinkTime += uplinkTime;
                m_stats.totalDownlinkTime += downlinkTime;
                m_stats.totalOffloadEnergy += offloadEnergy;
            
                double queueWaitTime = GetQueueWaitingTime();
            
                NS_LOG_INFO("*** QUEUED task " << task.taskId << " (position " << m_taskQueue.size() 
                           << " in queue), estimated wait: " << queueWaitTime << "ms ***");
            
                // Log with queue information
                LogTaskDecision(task, "QUEUED", uplinkTime, processingTime, 
                              downlinkTime, totalOffloadTime + queueWaitTime, localTime, offloadEnergy, 
                              localEnergy, (totalOffloadTime + queueWaitTime) <= task.deadline, 
                              hopCount, path, "MEC busy - added to queue", sinr, dataRate, 
                              queueWaitTime, linkStateSummary, blockedHops);
            
                return {"QUEUED", "Added to queue - MEC busy"};
            } else {
                // Queue is full - reject
                m_stats.localTasks++;
                double queueWaitTime = GetQueueWaitingTime();
                LogTaskDecision(task, "EXECUTE_LOCALLY", uplinkTime, processingTime, 
                              downlinkTime, totalOffloadTime, localTime, offloadEnergy, 
                              localEnergy, localTime <= task.deadline, hopCount, path, 
                              "MEC full and queue full", sinr, dataRate, queueWaitTime, 
                              linkStateSummary, blockedHops);
                m_stats.totalLocalEnergy += localEnergy;
                return {"EXECUTE_LOCALLY", "MEC and queue full"};
            }
        }
    
        // Direct processing - no queue needed
        m_activeTasks.push_back(task);
        m_stats.offloadedTasks++;
        m_stats.offloadedByPriority[task.priority-1]++;
        m_stats.totalHops += hopCount;
    
        if (hopCount == 1) m_stats.singleHopTasks++;
        else if (hopCount == 2) m_stats.twoHopTasks++;
        else if (hopCount == 3) m_stats.threeHopTasks++;
    
        // Track statistics
        m_stats.totalUplinkTime += uplinkTime;
        m_stats.totalProcessingTime += processingTime;
        m_stats.totalDownlinkTime += downlinkTime;
        m_stats.totalOffloadEnergy += offloadEnergy;
    
        // Use effective processing time considering CPU efficiency
        double effectiveProcessingTime = GetEffectiveProcessingTime(task);
    
        // Schedule task completion
        Simulator::Schedule(MilliSeconds(effectiveProcessingTime), 
                          &CentralSchedulerApplication::CompleteTask, this, task.taskId);
    
        LogTaskDecision(task, "OFFLOAD", uplinkTime, effectiveProcessingTime, 
                      downlinkTime, totalOffloadTime, localTime, offloadEnergy, 
                      localEnergy, totalOffloadTime <= task.deadline, hopCount, path, 
                      reason, sinr, dataRate, 0.0, linkStateSummary, blockedHops);
    
        NS_LOG_INFO("*** OFFLOADED task " << task.taskId << " through " << hopCount << " hops ***");
        NS_LOG_INFO("*** Link States: " << linkStateSummary << ", Blocked hops: " << blockedHops << " ***");
        NS_LOG_INFO("*** CPU Efficiency: " << m_currentCPUEfficiency * 100 << "%, Processing: " << effectiveProcessingTime << "ms ***");
    
        return {"OFFLOAD", reason};
    }
    
    void LogTaskDecision(const ComputationTask& task, const std::string& decision,
                    double uplinkTime, double processingTime, double downlinkTime,
                    double totalOffloadTime, double localTime,
                    double offloadEnergy, double localEnergy,
                    bool metDeadline, uint32_t hopCount, const std::vector<uint32_t>& path,
                    const std::string& reason, double sinr, double dataRate, 
                    double queueWaitTime, const std::string& linkStateSummary, uint32_t blockedHops) {
    
        m_taskLog << task.taskId << "," << task.ueId << "," << task.priority << "," 
                  << decision << "," << hopCount << ","
                  << uplinkTime << "," << processingTime << "," << downlinkTime << ","
                  << totalOffloadTime << "," << localTime << "," << task.deadline << ","
                  << metDeadline << "," << offloadEnergy << "," << localEnergy << ","
                  << FormatPath(path) << "," << sinr << "," << dataRate/1e6 << ","
                  << queueWaitTime << "," << m_currentCPUEfficiency << ","
                  << linkStateSummary << "," << blockedHops << "\n";
    }
    
    std::string FormatPath(const std::vector<uint32_t>& path) {
        std::stringstream ss;
        for (size_t i = 0; i < path.size(); i++) {
            if (i > 0) ss << "-";
            ss << path[i];
        }
        return ss.str();
    }
    
    // Member variables
    Ptr<Socket> m_socket;
    uint16_t m_port;
    uint32_t m_mecCapacity;
    
    // Existing parameters
    double m_mecFrequency;
    double m_uplinkRate;      // Now used as fallback only
    double m_downlinkRate;    // Now used as fallback only  
    double m_transmitPower;
    double m_ueFrequency;
    double m_kappa;
    
    // New mmWave parameters
    double m_carrierFrequency;
    double m_ueNoiseFigure;
    double m_gnbNoiseFigure;
    double m_ueTxPower;
    double m_iabTxPower;
    double m_donorTxPower;
    double m_ueAntennaGain;
    double m_iabAntennaGain;
    double m_donorAntennaGain;
    
    TaskStatistics m_stats;
    std::ofstream m_taskLog;
    Ptr<DAGTopology> m_dagTopology;
};

NS_OBJECT_ENSURE_REGISTERED(UeTaskGeneratorApplication);
NS_OBJECT_ENSURE_REGISTERED(CentralSchedulerApplication);
NS_OBJECT_ENSURE_REGISTERED(DAGTopology);
NS_OBJECT_ENSURE_REGISTERED(LinkStateManager);

int main(int argc, char *argv[])
{
    double simTime = 15; // Increased simulation time for more data
    bool verbose = true;

    CommandLine cmd(__FILE__);
    cmd.AddValue("simTime", "Total duration of simulation", simTime);
    cmd.AddValue("verbose", "Enable verbose logging", verbose);
    cmd.Parse(argc, argv);

    if (verbose) {
        LogComponentEnable("MmWaveIabMecDAG", LOG_LEVEL_INFO);
        // LogComponentEnable("LinkStateManager", LOG_LEVEL_DEBUG);
    }

    // Create DAG topology first
    Ptr<DAGTopology> dagTopology = CreateObject<DAGTopology>();
    dagTopology->InitializeTopology();

    Ptr<MmWaveHelper> mmwaveHelper = CreateObject<MmWaveHelper>();
    Ptr<MmWavePointToPointEpcHelper> epcHelper = CreateObject<MmWavePointToPointEpcHelper>();
    mmwaveHelper->SetEpcHelper(epcHelper);
    mmwaveHelper->SetHarqEnabled(true);

    Ptr<Node> pgw = epcHelper->GetPgwNode();

    // Create nodes according to DAG topology
    NodeContainer allNodes;
    allNodes.Create(9); // 1 gNB + 8 IAB nodes

    NodeContainer donorNode;
    donorNode.Add(allNodes.Get(0));

    NodeContainer iabNodes;
    for (uint32_t i = 1; i < 9; i++) {
        iabNodes.Add(allNodes.Get(i));
    }

    // Create UEs - SCALED to 40 UEs (optimal balance)
    NodeContainer ueNodes;
    ueNodes.Create(30); // 40 UEs total

    MobilityHelper mobility;
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();

    // Position nodes according to DAG topology
    for (uint32_t i = 0; i < allNodes.GetN(); i++) {
        Vector pos = dagTopology->GetNodePosition(i);
        positionAlloc->Add(pos);
    }

    // Position UEs around their attached IAB nodes - distribute among 8 IAB nodes
    for (uint32_t i = 0; i < ueNodes.GetN(); i++) {
        uint32_t iabNodeId = 1 + (i % 8); // Distribute UEs among IAB nodes 1-8
        Vector iabPos = dagTopology->GetNodePosition(iabNodeId);
        
        // Position UE near its IAB node with some random offset
        std::random_device rd;
        std::mt19937 gen(rd() + i);
        std::uniform_real_distribution<> offsetDist(-25.0, 25.0);
        
        Vector uePos = iabPos + Vector(offsetDist(gen), offsetDist(gen), -10.0);
        positionAlloc->Add(uePos);
    }

    mobility.SetPositionAllocator(positionAlloc);
    mobility.Install(NodeContainer(allNodes, ueNodes));

    InternetStackHelper internet;
    internet.Install(NodeContainer(iabNodes, ueNodes));

    // Install network devices
    NetDeviceContainer donorDev = mmwaveHelper->InstallEnbDevice(donorNode);
    NetDeviceContainer iabDevs = mmwaveHelper->InstallEnbDevice(iabNodes);
    NetDeviceContainer iabUeDevs = mmwaveHelper->InstallUeDevice(iabNodes);
    NetDeviceContainer ueDevs = mmwaveHelper->InstallUeDevice(ueNodes);

    // Attach IAB nodes to donor according to DAG topology
    mmwaveHelper->AttachToClosestEnb(iabUeDevs, donorDev);

    // Attach UEs to their IAB nodes
    for (uint32_t ue = 0; ue < ueNodes.GetN(); ue++) {
        uint32_t iabNodeId = 1 + (ue % 8); // UE attached to IAB nodes 1-8
        NetDeviceContainer singleUeDev;
        singleUeDev.Add(ueDevs.Get(ue));
        NetDeviceContainer singleIabDev;
        singleIabDev.Add(iabDevs.Get(iabNodeId - 1)); // IAB devs index from 0
        mmwaveHelper->AttachToClosestEnb(singleUeDev, singleIabDev);
    }

    Ipv4InterfaceContainer iabIpIfaces = epcHelper->AssignUeIpv4Address(iabUeDevs);
    Ipv4InterfaceContainer ueIpIfaces = epcHelper->AssignUeIpv4Address(ueDevs);

    Ipv4Address schedulerAddress = pgw->GetObject<Ipv4>()->GetAddress(1, 0).GetLocal();

    Ipv4StaticRoutingHelper ipv4RoutingHelper;
    for (uint32_t i = 0; i < ueNodes.GetN(); i++) {
        Ptr<Ipv4StaticRouting> ueStaticRouting = ipv4RoutingHelper.GetStaticRouting(ueNodes.Get(i)->GetObject<Ipv4>());
        ueStaticRouting->SetDefaultRoute(epcHelper->GetUeDefaultGatewayAddress(), 1);
    }
    for (uint32_t i = 0; i < iabNodes.GetN(); i++) {
        Ptr<Ipv4StaticRouting> iabStaticRouting = ipv4RoutingHelper.GetStaticRouting(iabNodes.Get(i)->GetObject<Ipv4>());
        iabStaticRouting->SetDefaultRoute(epcHelper->GetUeDefaultGatewayAddress(), 1);
    }

    // Setup scheduler with DAG topology
    Ptr<CentralSchedulerApplication> scheduler = CreateObject<CentralSchedulerApplication>();
    scheduler->Setup(9999, dagTopology);
    pgw->AddApplication(scheduler);
    scheduler->SetStartTime(Seconds(0.1));
    scheduler->SetStopTime(Seconds(simTime));

    // Setup UE applications with their attached IAB nodes
    for (uint32_t ue = 0; ue < ueNodes.GetN(); ue++) {
        uint32_t attachedIabNode = 1 + (ue % 8); // UE attached to IAB nodes 1-8
        Ptr<UeTaskGeneratorApplication> taskGen = CreateObject<UeTaskGeneratorApplication>();
        taskGen->Setup(schedulerAddress, 9999, ue, attachedIabNode, dagTopology);
        ueNodes.Get(ue)->AddApplication(taskGen);
        // More staggered start times for 40 UEs
        taskGen->SetStartTime(Seconds(1.0 + (ue % 20) * 0.05));
        taskGen->SetStopTime(Seconds(simTime - 1.0));
    }

    NS_LOG_INFO("=== 5G NR IAB + MEC DAG MULTIHOP Simulation ===");
    NS_LOG_INFO("=== ENHANCED WITH REALISTIC NLOS/LOS mmWave CHANNEL MODEL ===");
    NS_LOG_INFO("OPTIMAL SCALED CONFIGURATION: 30 UEs, MEC Capacity=20, Queue Size=10");
    NS_LOG_INFO("DAG TOPOLOGY: 9 Nodes (1 gNB + 8 IAB)");
    NS_LOG_INFO("UE DISTRIBUTION: 40 UEs (5 UEs per IAB node on average)");
    NS_LOG_INFO("MAX HOPS: 3");
    NS_LOG_INFO("ROUTING: BFS-based path finding with load balancing");
    NS_LOG_INFO("LINK STATES: Dynamic LOS/NLOS/Blocked conditions based on 3GPP UMi model");
    NS_LOG_INFO("SIMULATION TIME: " << simTime << " seconds");

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();
    Simulator::Destroy();
    
    NS_LOG_INFO("=== Enhanced DAG Multihop simulation completed successfully ===");
    NS_LOG_INFO("Check task_metrics_multihop_enhanced.csv for detailed analysis with link states");
    return 0;
}